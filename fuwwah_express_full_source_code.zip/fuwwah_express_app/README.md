# فوه إكسبريس - تطبيق التوصيل وشحن الطرود (Fuwwah Express)
منصة توصيل متكاملة لمدينة فوه بمحافظة كفر الشيخ - ربط المتاجر والعملاء وشحن الطرود مع تتبع حي بالخريطة والدفع بانستا باي والمحافظ الإلكترونية، ومشروع أندرويد ستوديو مجهز لبناء ملف APK موقّع.

---

## محتويات المشروع (Project Structure):
- `src/` : الكود المصدري الكامل لتطبيق React + TypeScript + Tailwind CSS مع الخريطة التفاعلية ونظام التتبع وبوابات الدفع.
- `public/` : أيقونات PWA وأصول التطبيق وملفات الـ APK المباشرة.
- `android/` : مشروع Android Studio كامل ومستقل لبناء ملف APK موقّع أو نشره على Google Play Store:
  - `android/app/src/main/AndroidManifest.xml` (أذونات الـ GPS وتتبع الشحنات)
  - `android/app/src/main/java/.../MainActivity.java` (حاوية أندرويد أصلية مع دعم تحديد الموقع وفتح المكالمات وواتساب)
  - `android/app/build.gradle` (إعدادات التوقيع وحزمة com.fuwwah.express.delivery)

---

## 1. تشغيل تطبيق الويب محلياً (Run Web App Locally):
```bash
# 1. تثبيت الحزم:
npm install

# 2. تشغيل خادم التطوير:
npm run dev

# 3. بناء نسخة الإنتاج:
npm run build
```

---

## 2. بناء ملف APK موقّع عبر Android Studio (Build Signed Android APK):
1. افتح برنامج **Android Studio**.
2. اختر **Open** وحدد مجلد `android` الموجود داخل هذا المشروع.
3. انتظر انتهاء مزامنة Gradle (Gradle Sync).
4. من القائمة العلوية: **Build** -> **Generate Signed Bundle / APK...**
5. اختر **APK** ثم اضغط **Next**.
6. حدد أو أنشئ مفتاح التوقيع الرقمي (Keystore)، أدخل كلمة المرور والـ Alias.
7. اختر صيغة **release**، وحدد خياري التوقيع **V1 (Jar Signature)** و **V2 (Full APK Signature)**.
8. اضغط **Finish**؛ سيتم توليد ملف الـ APK الموقّع داخل:
   `android/app/build/outputs/apk/release/app-release.apk`

---

## 3. بناء ملف APK عبر سطر الأوامر (Terminal / CLI):
```bash
cd android

# 1. إنشاء مفتاح توقيع رقمي:
keytool -genkey -v -keystore app/fuwwah-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias fuwwah-key

# 2. بناء حزمة الإصدار الموقعة:
./gradlew assembleRelease
```
