import React, { useState } from 'react';
import { Order, Store, ProductItem } from '../types';
import { INITIAL_STORES } from '../data/fuwwahData';
import { Store as StoreIcon, CheckCircle2, Clock, Plus, Bike, ShoppingBag, Banknote, ShieldCheck } from 'lucide-react';

interface MerchantDashboardProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, newStatus: any) => void;
  onSelectTrackOrder: (order: Order) => void;
}

export const MerchantDashboard: React.FC<MerchantDashboardProps> = ({
  orders,
  onUpdateOrderStatus,
  onSelectTrackOrder,
}) => {
  const [currentStore, setCurrentStore] = useState<Store>(INITIAL_STORES[0]);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [newProductName, setNewProductName] = useState('');
  const [newProductPrice, setNewProductPrice] = useState('');
  const [newProductCategory, setNewProductCategory] = useState('أصناف رئيسية');
  const [newProductDesc, setNewProductDesc] = useState('');

  // Orders for this store or parcel shipments originating from this location
  const storeOrders = orders.filter(
    (o) => o.storeId === currentStore.id || o.pickupLocation.name.includes(currentStore.name)
  );

  const totalStoreRevenue = storeOrders
    .filter((o) => o.paymentStatus === 'verified' || o.status === 'delivered')
    .reduce((acc, o) => acc + o.subtotal, 0);

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProductName.trim() || !newProductPrice) return;

    const newProd: ProductItem = {
      id: `p_new_${Date.now()}`,
      name: newProductName,
      price: Number(newProductPrice),
      category: newProductCategory,
      description: newProductDesc || 'منتج طازج ومعد بعناية في فوه.',
      isPopular: false,
    };

    setCurrentStore((prev) => ({
      ...prev,
      products: [newProd, ...prev.products],
    }));

    setNewProductName('');
    setNewProductPrice('');
    setNewProductDesc('');
    setIsAddingProduct(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Merchant Switcher & Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
            <StoreIcon className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">{currentStore.name}</h2>
              <span className="text-xs bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-0.5 rounded-full font-bold">
                متجر معتمد في فوه
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {currentStore.address} · الهاتف: {currentStore.phone}
            </p>
          </div>
        </div>

        {/* Store Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-semibold">تبديل المتجر:</span>
          <select
            value={currentStore.id}
            onChange={(e) => {
              const s = INITIAL_STORES.find((item) => item.id === e.target.value);
              if (s) setCurrentStore(s);
            }}
            className="text-xs font-bold px-3 py-2 bg-slate-50 rounded-xl border border-slate-300 text-slate-800 focus:ring-2 focus:ring-emerald-500"
          >
            {INITIAL_STORES.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.categoryAr})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500">إجمالي المبيعات المؤكدة</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-emerald-700 tabular-nums">{totalStoreRevenue}</span>
            <span className="text-xs text-slate-500 font-bold">جنيه مصري</span>
          </div>
          <span className="text-[11px] text-emerald-600 font-semibold block mt-1">
            تسوية فورية عبر انستا باي والمحافظ
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500">طلبات المتجر الجارية</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-slate-900 tabular-nums">
              {storeOrders.filter((o) => o.status !== 'delivered').length}
            </span>
            <span className="text-xs text-slate-500 font-bold">طلبات نشطة</span>
          </div>
          <span className="text-[11px] text-slate-500 block mt-1">في شوارع فوه حالياً</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500">عدد المنتجات المسجلة</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-slate-900 tabular-nums">
              {currentStore.products.length}
            </span>
            <span className="text-xs text-slate-500 font-bold">صنف متاح</span>
          </div>
          <span className="text-[11px] text-blue-600 font-semibold block mt-1">
            جاهزة للطلب والتوصيل للعملاء
          </span>
        </div>
      </div>

      {/* Orders Management */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-emerald-600" />
            <span>طلبات زبائن فوه الواردة للمتجر</span>
          </h3>
          <span className="text-xs text-slate-500">تحديث تلقائي</span>
        </div>

        {storeOrders.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-xs">
            لا توجد طلبات جارية لهذا المتجر حالياً. يمكنك تجربة طلب صنف من واجهة العميل!
          </div>
        ) : (
          <div className="space-y-3">
            {storeOrders.map((ord) => (
              <div
                key={ord.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition-colors flex flex-wrap items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-900">
                      {ord.trackingNumber}
                    </span>
                    <span className="text-xs font-bold text-slate-800">العميل: {ord.customerName}</span>
                    <span className="text-[11px] text-slate-400">· {ord.customerPhone}</span>
                  </div>

                  <p className="text-xs text-slate-600">
                    مكان التسليم: <strong className="text-slate-900">{ord.dropoffLocation.name}</strong> ({ord.dropoffLocation.district})
                  </p>

                  <div className="flex items-center gap-2 text-[11px] text-slate-500">
                    <span>
                      طريقة الدفع:{' '}
                      <strong className="text-emerald-700">
                        {ord.paymentMethod === 'instapay'
                          ? 'انستا باي'
                          : ord.paymentMethod.includes('cash')
                          ? 'محفظة كاش'
                          : 'كاش عند الاستلام'}
                      </strong>
                    </span>
                    <span>·</span>
                    <span>
                      المبلغ: <strong className="text-slate-900 tabular-nums">{ord.total} ج.م</strong>
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  {ord.status === 'confirmed' && (
                    <button
                      type="button"
                      onClick={() => onUpdateOrderStatus(ord.id, 'preparing')}
                      className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl text-xs font-bold shadow-sm"
                    >
                      بدء التجهيز في المتجر
                    </button>
                  )}

                  {ord.status === 'preparing' && (
                    <button
                      type="button"
                      onClick={() => onUpdateOrderStatus(ord.id, 'on_the_way')}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm flex items-center gap-1.5"
                    >
                      <Bike className="w-3.5 h-3.5" />
                      <span>تسليم للمندوب والتوصيل</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => onSelectTrackOrder(ord)}
                    className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-sm"
                  >
                    تتبع الشحنة عالخريطة
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Menu / Product Management for the Store */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="font-bold text-slate-900 text-base">قائمة أصناف ومنتجات المتجر في فوه</h3>
            <p className="text-xs text-slate-500 mt-0.5">يمكنك إضافة أطباق جديدة أو قطع سجاد أو منتجات بقالة</p>
          </div>

          <button
            type="button"
            onClick={() => setIsAddingProduct(!isAddingProduct)}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>{isAddingProduct ? 'إلغاء' : 'إضافة صنف جديد'}</span>
          </button>
        </div>

        {/* Add Product Form */}
        {isAddingProduct && (
          <form onSubmit={handleCreateProduct} className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200 space-y-3">
            <h4 className="text-xs font-bold text-emerald-900">بيانات الصنف الجديد:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">اسم الصنف أو المنتج</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: كيلو كباب ضاني / كليم فوه أزرق"
                  value={newProductName}
                  onChange={(e) => setNewProductName(e.target.value)}
                  className="w-full h-9 px-3 text-xs bg-white rounded-lg border border-emerald-300 font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">السعر بالجنيه (ج.م)</label>
                <input
                  type="number"
                  required
                  placeholder="مثال: 120"
                  value={newProductPrice}
                  onChange={(e) => setNewProductPrice(e.target.value)}
                  className="w-full h-9 px-3 text-xs bg-white rounded-lg border border-emerald-300 font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">القسم</label>
                <input
                  type="text"
                  placeholder="مثال: مأكولات / سجاد يدوي / حلويات"
                  value={newProductCategory}
                  onChange={(e) => setNewProductCategory(e.target.value)}
                  className="w-full h-9 px-3 text-xs bg-white rounded-lg border border-emerald-300"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">الوصف والمكونات</label>
              <input
                type="text"
                placeholder="وصف مختصر للمنتج يجذب زبائن فوه"
                value={newProductDesc}
                onChange={(e) => setNewProductDesc(e.target.value)}
                className="w-full h-9 px-3 text-xs bg-white rounded-lg border border-emerald-300"
              />
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsAddingProduct(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 font-semibold"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold"
              >
                حفظ وإضافة للمتجر
              </button>
            </div>
          </form>
        )}

        {/* Existing Products List */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {currentStore.products.map((p) => (
            <div
              key={p.id}
              className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between"
            >
              <div>
                <p className="font-bold text-slate-900 text-xs">{p.name}</p>
                <p className="text-[11px] text-slate-500 truncate max-w-[200px]">{p.description}</p>
                <span className="text-[10px] text-emerald-700 font-bold">{p.category}</span>
              </div>
              <span className="font-mono font-black text-sm text-slate-900 tabular-nums">
                {p.price} ج.م
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
