import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import {
  Smartphone,
  Download,
  QrCode,
  CheckCircle2,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  ArrowDownToLine,
  Info,
  FolderArchive,
  Terminal,
  Key,
} from 'lucide-react';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isAndroid, isIOS, install } = usePWAInstall();
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'instant_webapk' | 'generate_apk' | 'android_project' | 'qr'>('instant_webapk');

  // Public Shared App URL (Accessible globally on any mobile device)
  const sharedUrl = 'https://ais-pre-hzolmjlpjzsytaaezrqw5l-648315247205.europe-west3.run.app';
  const appUrl = typeof window !== 'undefined' && window.location.origin.includes('run.app')
    ? window.location.origin
    : sharedUrl;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const copyCommand = (cmd: string, key: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCmd(key);
    setTimeout(() => setCopiedCmd(null), 2500);
  };

  const handleNativeInstall = async () => {
    if (isInstallable) {
      await install();
    } else {
      alert('لتثبيت التطبيق مباشرة: انقر على قائمة المتصفح (الثلاث نقاط ⋮ أعلى أو أسفل الشاشة) ثم اختر "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".');
    }
  };

  // Direct PWABuilder link for generating standalone signed APK package
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(appUrl)}`;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[2200] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-slate-900 text-white p-6 pb-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-emerald-400" />
              <span className="text-xs font-bold text-emerald-300">تحميل وتصدير تطبيق أندرويد (Signed APK & Studio)</span>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white text-xs font-bold px-2 py-1 rounded-md hover:bg-white/10 transition-colors"
            >
              ✕ إغلاق
            </button>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/10 p-1 border border-white/20 flex items-center justify-center shrink-0">
              <img src="/icon.svg" alt="فوه إكسبريس" className="w-12 h-12" />
            </div>
            <div>
              <h3 className="text-xl font-bold">تطبيق فوه إكسبريس (Android APK Project)</h3>
              <p className="text-xs text-slate-300 mt-0.5">
                تنزيل ملف الـ APK المباشر، أو تثبيت WebAPK، أو تصدير مشروع Android Studio كامل
              </p>
            </div>
          </div>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-4 p-2 bg-slate-100 gap-1 border-b border-slate-200 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('instant_webapk')}
            className={`py-2 px-2 rounded-xl text-center transition-all ${
              activeTab === 'instant_webapk'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            تثبيت (WebAPK)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('generate_apk')}
            className={`py-2 px-2 rounded-xl text-center transition-all ${
              activeTab === 'generate_apk'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            ملف APK مباشر
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('android_project')}
            className={`py-2 px-2 rounded-xl text-center transition-all ${
              activeTab === 'android_project'
                ? 'bg-white text-emerald-800 shadow-sm border border-emerald-300'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            مشروع Studio كامل
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('qr')}
            className={`py-2 px-2 rounded-xl text-center transition-all ${
              activeTab === 'qr'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            مسح (QR)
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* TAB 1: INSTANT INSTALL VIA ANDROID WEBAPK */}
          {activeTab === 'instant_webapk' && (
            <div className="space-y-4">
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-emerald-950">
                    التثبيت الرسمي المباشر من Google و Android (بدون الحاجة لمتجر)
                  </h4>
                  <p className="text-[11px] text-emerald-800 leading-relaxed">
                    نظام أندرويد يدعم تثبيت التطبيق مباشرة كـ <strong>WebAPK</strong> مع أيقونة مستقلة على شاشتك الرئيسية، شاشة كاملة، وتتبع مباشر للخريطة واستقبال الطلبات فورياً!
                  </p>
                </div>
              </div>

              {isInstalled ? (
                <div className="p-4 bg-slate-100 rounded-2xl text-center space-y-1">
                  <span className="text-xs font-bold text-emerald-700">✓ التطبيق مثبت بالفعل على هذا الجهاز!</span>
                  <p className="text-[11px] text-slate-500">يعمل الآن بكامل طاقته في الوضع المستقل (Standalone).</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <button
                    type="button"
                    onClick={handleNativeInstall}
                    className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 active:scale-[0.98]"
                  >
                    <ArrowDownToLine className="w-5 h-5" />
                    <span>تثبيت التطبيق على هاتفك الأندرويد الآن (نقرة واحدة)</span>
                  </button>

                  {/* Direct Link Box */}
                  <div className="p-3 bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between gap-2">
                    <div className="overflow-hidden">
                      <span className="text-[10px] text-slate-500 font-bold block">رابط التطبيق المباشر للهاتف:</span>
                      <p className="text-xs font-mono font-bold text-slate-900 truncate select-all">{appUrl}</p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={handleCopyLink}
                        className="px-3 py-1.5 bg-white text-slate-800 hover:bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold flex items-center gap-1"
                      >
                        {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedLink ? 'تم النسخ' : 'نسخ'}</span>
                      </button>
                      <a
                        href={appUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1.5 bg-slate-900 text-white hover:bg-slate-800 rounded-lg text-xs font-bold flex items-center gap-1"
                      >
                        <span>فتح</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 space-y-1.5">
                    <p className="font-bold text-slate-900">إذا لم تظهر رسالة التثبيت التلقائية:</p>
                    <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600 pr-1">
                      <li>افتح الرابط أعلاه من متصفح <strong>Google Chrome</strong> على هاتفك الأندرويد.</li>
                      <li>اضغط على زر الخيارات (<strong>الثلاث نقاط ⋮</strong> أعلى يسار المتصفح).</li>
                      <li>اختر <strong>«تثبيت التطبيق» (Install app)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.</li>
                      <li>سيتم تنزيل الأيقونة فوراً وستجد التطبيق بين تطبيقات هاتفك!</li>
                    </ol>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: GENERATE APK WITH PWABUILDER */}
          {activeTab === 'generate_apk' && (
            <div className="space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                <span className="text-xs font-bold text-slate-900 block">
                  تحويل التطبيق إلى ملف APK كامل (Android APK / AAB)
                </span>
                <p className="text-xs text-slate-600 leading-relaxed">
                  تطبيق <strong>فوه إكسبريس</strong> مجهز بالكامل بملفات <code>manifest.json</code> وأيقونات أندرويد و <code>Service Worker</code>. يمكنك تحويله لملف <strong>APK جاهز للتنزيل المباشر أو الرفع على Google Play</strong> عبر أداة PWABuilder الرسمية:
                </p>

                <div className="pt-2 space-y-2">
                  {/* Direct APK file download */}
                  <a
                    href="/fuwwah_express.apk"
                    download="fuwwah_express.apk"
                    className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>تحميل ملف التطبيق المباشر (fuwwah_express.apk)</span>
                  </a>

                  {/* Cloud Signed APK Builder */}
                  <a
                    href={pwaBuilderUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                    <span>توليد حزمة APK موقعة لمتجر Google Play (أونلاين)</span>
                  </a>
                </div>
              </div>

              {/* Instructions */}
              <div className="p-3.5 bg-blue-50/60 border border-blue-200 rounded-xl text-xs text-blue-900 space-y-1">
                <span className="font-bold block">خطوات تنزيل ملف الـ APK في ثوانٍ:</span>
                <p className="text-[11px] leading-relaxed">
                  1. اضغط على الزر أعلاه للانتقال لأداة PWABuilder.<br />
                  2. اضغط على <strong>«Package For Stores»</strong> ثم اختر <strong>Android</strong>.<br />
                  3. اضغط على <strong>Generate APK</strong> لتنزيل ملف الـ APK وتثبيته مباشرة على أي جهاز أندرويد.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: COMPLETE ANDROID STUDIO PROJECT (SIGNED APK READY) */}
          {activeTab === 'android_project' && (
            <div className="space-y-4">
              {/* Download Zip Card */}
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                      <FolderArchive className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">مشروع أندرويد ستوديو الأصلي الكامل</h4>
                      <p className="text-[11px] text-slate-600">
                        حزمة Gradle كاملة مع الكود المصدري وواجهة WebView والأصول المجمعة (264 KB)
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 pt-1">
                  <a
                    href="/fuwwah_express_full_source_code.zip"
                    download="fuwwah_express_full_source_code.zip"
                    className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>تحميل الكود المصدري الكامل للمشروع بالكامل + ملفات الأندرويد (.ZIP - 4.7 MB)</span>
                  </a>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <a
                      href="/fuwwah_express_android_project.zip"
                      download="fuwwah_express_android_project.zip"
                      className="py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2 active:scale-95"
                    >
                      <FolderArchive className="w-4 h-4 text-emerald-400" />
                      <span>مشروع Android Studio فقط (.ZIP - 264 KB)</span>
                    </a>

                    <a
                      href="/fuwwah_express.apk"
                      download="fuwwah_express.apk"
                      className="py-2.5 px-3 bg-white hover:bg-slate-50 text-slate-900 border border-slate-300 rounded-xl text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2 active:scale-95"
                    >
                      <Smartphone className="w-4 h-4 text-emerald-600" />
                      <span>تنزيل ملف fuwwah_express.apk</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Project Specs */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2">
                <span className="font-bold text-slate-900 block">مواصفات حزمة الأندرويد المجهزة:</span>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 font-mono">
                  <div>Package: <strong className="text-slate-900">com.fuwwah.express.delivery</strong></div>
                  <div>Min SDK: <strong className="text-slate-900">24 (Android 7.0+)</strong></div>
                  <div>Target SDK: <strong className="text-slate-900">34 (Android 14+)</strong></div>
                  <div>Gradle: <strong className="text-slate-900">8.2.2 / JDK 17</strong></div>
                </div>
              </div>

              {/* Instructions to Generate Signed APK */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-900 block">
                  خطوات استخراج ملف APK الموقّع (Signed APK):
                </span>

                {/* Step 1: Open */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-slate-900">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-bold">1</span>
                    <span>افتح المجلد في Android Studio:</span>
                  </div>
                  <p className="text-[11px] text-slate-600 pr-6">
                    قم بفك ضغط الملف وافتح مجلد <code>android</code> داخل <strong>Android Studio</strong> وانتظر اكتمال مزامنة Gradle تلقائياً.
                  </p>
                </div>

                {/* Step 2: Keystore */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-bold text-slate-900">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-bold">2</span>
                      <span>توليد مفتاح التوقيع الرقمي (Keystore):</span>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        copyCommand(
                          'keytool -genkey -v -keystore app/fuwwah-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias fuwwah-key',
                          'keytool'
                        )
                      }
                      className="text-[11px] text-emerald-700 font-bold hover:underline flex items-center gap-1"
                    >
                      {copiedCmd === 'keytool' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedCmd === 'keytool' ? 'تم النسخ' : 'نسخ الأمر'}</span>
                    </button>
                  </div>
                  <pre className="text-[10px] bg-slate-900 text-emerald-400 p-2.5 rounded-lg font-mono overflow-x-auto whitespace-pre-wrap dir-ltr text-left">
keytool -genkey -v -keystore app/fuwwah-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias fuwwah-key
                  </pre>
                </div>

                {/* Step 3: Build */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-bold text-slate-900">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-bold">3</span>
                      <span>بناء ملف الـ APK الموقّع للإنتاج:</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => copyCommand('./gradlew assembleRelease', 'gradle')}
                      className="text-[11px] text-emerald-700 font-bold hover:underline flex items-center gap-1"
                    >
                      {copiedCmd === 'gradle' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedCmd === 'gradle' ? 'تم النسخ' : 'نسخ الأمر'}</span>
                    </button>
                  </div>
                  <pre className="text-[10px] bg-slate-900 text-emerald-400 p-2.5 rounded-lg font-mono overflow-x-auto dir-ltr text-left">
./gradlew assembleRelease
                  </pre>
                  <p className="text-[11px] text-slate-500 pt-0.5">
                    ستجد ملف الـ APK الموقّع في المسار: <code>app/build/outputs/apk/release/app-release.apk</code>
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: QR CODE & LINK */}
          {activeTab === 'qr' && (
            <div className="space-y-4 text-center">
              <p className="text-xs text-slate-600">
                امسح رمز الاستجابة السريع (QR) بكاميرا هاتفك لفتح التطبيق وتثبيته فوراً في فوه:
              </p>

              <div className="w-44 h-44 mx-auto bg-white p-3 rounded-2xl border-2 border-slate-200 shadow-sm flex items-center justify-center">
                <div className="space-y-1">
                  <QrCode className="w-28 h-28 mx-auto text-slate-800" />
                  <span className="text-[10px] font-bold text-slate-500 block">كاميرا الهاتف</span>
                </div>
              </div>

              <div className="flex items-center gap-2 bg-slate-100 p-2 rounded-xl text-xs">
                <input
                  type="text"
                  readOnly
                  value={appUrl}
                  className="flex-1 bg-transparent px-2 text-[11px] font-mono text-slate-800 truncate focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="px-3 py-1.5 bg-white rounded-lg border border-slate-300 font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-1 shrink-0"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'تم النسخ' : 'نسخ الرابط'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Footer Close */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-100 text-xs">
            <span className="text-slate-500 text-[11px]">فوه إكسبريس · جاهز للعمل على جميع أجهزة Android</span>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold transition-colors"
            >
              تم
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
