import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { LocationPoint, Courier } from '../types';
import { FUWWAH_CENTER, FUWWAH_LANDMARKS } from '../data/fuwwahData';
import { MapPin, Navigation, Search, Crosshair, Store as StoreIcon, Bike } from 'lucide-react';

interface InteractiveMapProps {
  mode?: 'explore' | 'pick_pickup' | 'pick_dropoff' | 'track_order';
  pickupLocation?: LocationPoint | null;
  dropoffLocation?: LocationPoint | null;
  courierLocation?: [number, number] | null;
  courierInfo?: Courier | null;
  onSelectLocation?: (point: LocationPoint, type: 'pickup' | 'dropoff') => void;
  heightClass?: string;
  showLandmarks?: boolean;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  mode = 'explore',
  pickupLocation,
  dropoffLocation,
  courierLocation,
  courierInfo,
  onSelectLocation,
  heightClass = 'h-[440px] md:h-[520px]',
  showLandmarks = true,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const routeLineRef = useRef<L.Polyline | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLandmark, setSelectedLandmark] = useState<string | null>(null);
  const [activePickerTarget, setActivePickerTarget] = useState<'dropoff' | 'pickup'>(
    mode === 'pick_pickup' ? 'pickup' : 'dropoff'
  );

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return; // already initialized

    const map = L.map(mapContainerRef.current, {
      center: FUWWAH_CENTER,
      zoom: 15,
      zoomControl: false,
    });

    // Custom OpenStreetMap tile layer with high clarity
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors',
    }).addTo(map);

    // Zoom control at bottom left (RTL friendly)
    L.control.zoom({ position: 'bottomleft' }).addTo(map);

    const markersLayer = L.layerGroup().addTo(map);
    mapInstanceRef.current = map;
    markersLayerRef.current = markersLayer;

    // Click handler for location picking
    map.on('click', (e: L.LeafletMouseEvent) => {
      const { lat, lng } = e.latlng;
      // Find nearest Fuwwah landmark or district
      let nearestDistrict = 'مدينة فوه';
      let minDistance = Infinity;

      FUWWAH_LANDMARKS.forEach((lm) => {
        const d = Math.hypot(lm.lat - lat, lm.lng - lng);
        if (d < minDistance) {
          minDistance = d;
          nearestDistrict = lm.district || lm.name;
        }
      });

      const point: LocationPoint = {
        lat,
        lng,
        name: `موقع محدد بالقرب من ${nearestDistrict}`,
        district: nearestDistrict,
        details: `إحداثيات فوه: ${lat.toFixed(4)}, ${lng.toFixed(4)}`,
      };

      if (onSelectLocation) {
        onSelectLocation(point, activePickerTarget);
      }
    });

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update mode if prop changes
  useEffect(() => {
    if (mode === 'pick_pickup') setActivePickerTarget('pickup');
    if (mode === 'pick_dropoff') setActivePickerTarget('dropoff');
  }, [mode]);

  // Update markers and route lines when locations or tracking changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    const layer = markersLayerRef.current;
    if (!map || !layer) return;

    layer.clearLayers();

    if (routeLineRef.current) {
      routeLineRef.current.remove();
      routeLineRef.current = null;
    }

    const boundsPoints: [number, number][] = [];

    // 1. Draw Landmarks if requested
    if (showLandmarks && mode === 'explore') {
      FUWWAH_LANDMARKS.forEach((lm) => {
        const iconHtml = `
          <div class="flex items-center gap-1.5 bg-white/95 text-slate-800 text-[11px] font-semibold px-2 py-1 rounded-full shadow-md border border-slate-200 whitespace-nowrap hover:bg-emerald-50 transition-colors">
            <span class="w-2 h-2 rounded-full bg-emerald-600"></span>
            <span>${lm.name}</span>
          </div>
        `;
        const icon = L.divIcon({
          className: 'custom-landmark-icon',
          html: iconHtml,
          iconSize: [120, 24],
          iconAnchor: [60, 12],
        });

        const marker = L.marker([lm.lat, lm.lng], { icon });
        marker.bindPopup(`
          <div dir="rtl" class="text-right p-1 font-['Cairo']">
            <h4 class="font-bold text-sm text-emerald-800 mb-0.5">${lm.name}</h4>
            <p class="text-xs text-slate-600">${lm.district} - ${lm.details}</p>
            <button class="mt-2 text-xs bg-emerald-600 text-white px-2.5 py-1 rounded font-medium w-full text-center hover:bg-emerald-700">
              تحديد هذا المعلم
            </button>
          </div>
        `);
        marker.on('popupopen', () => {
          const btn = document.querySelector('.leaflet-popup button');
          if (btn) {
            btn.addEventListener('click', () => {
              if (onSelectLocation) {
                onSelectLocation(lm, activePickerTarget);
                map.closePopup();
              }
            });
          }
        });
        marker.addTo(layer);
      });
    }

    // 2. Pickup Location Marker (Green)
    if (pickupLocation) {
      boundsPoints.push([pickupLocation.lat, pickupLocation.lng]);
      const pickupHtml = `
        <div class="relative flex items-center justify-center">
          <div class="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg border-2 border-white ring-2 ring-emerald-300">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
          </div>
          <div class="absolute -bottom-6 bg-slate-900 text-white text-[10px] px-2 py-0.5 rounded shadow font-bold whitespace-nowrap">
            نقطة الاستلام
          </div>
        </div>
      `;
      const pickupIcon = L.divIcon({
        html: pickupHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });
      const pickupMarker = L.marker([pickupLocation.lat, pickupLocation.lng], { icon: pickupIcon }).addTo(layer);
      pickupMarker.bindPopup(`
        <div dir="rtl" class="text-right p-1 font-['Cairo']">
          <span class="text-[10px] text-emerald-600 font-bold">نقطة الاستلام (المتجر / المرسل)</span>
          <p class="font-bold text-slate-800 text-sm mt-0.5">${pickupLocation.name}</p>
          <p class="text-xs text-slate-500">${pickupLocation.details || pickupLocation.district || ''}</p>
        </div>
      `);
    }

    // 3. Dropoff Location Marker (Blue)
    if (dropoffLocation) {
      boundsPoints.push([dropoffLocation.lat, dropoffLocation.lng]);
      const dropoffHtml = `
        <div class="relative flex items-center justify-center">
          <div class="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg border-2 border-white ring-2 ring-blue-300 animate-bounce">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <div class="absolute -bottom-6 bg-blue-900 text-white text-[10px] px-2 py-0.5 rounded shadow font-bold whitespace-nowrap">
            موقع التسليم
          </div>
        </div>
      `;
      const dropoffIcon = L.divIcon({
        html: dropoffHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });
      const dropoffMarker = L.marker([dropoffLocation.lat, dropoffLocation.lng], {
        icon: dropoffIcon,
        draggable: mode === 'pick_dropoff',
      }).addTo(layer);

      dropoffMarker.bindPopup(`
        <div dir="rtl" class="text-right p-1 font-['Cairo']">
          <span class="text-[10px] text-blue-600 font-bold">موقع التوصيل (العميل)</span>
          <p class="font-bold text-slate-800 text-sm mt-0.5">${dropoffLocation.name}</p>
          <p class="text-xs text-slate-500">${dropoffLocation.details || dropoffLocation.district || ''}</p>
        </div>
      `);

      if (mode === 'pick_dropoff') {
        dropoffMarker.on('dragend', (ev) => {
          const latlng = ev.target.getLatLng();
          if (onSelectLocation) {
            onSelectLocation(
              {
                lat: latlng.lat,
                lng: latlng.lng,
                name: 'الموقع المحدد على الخريطة',
                district: 'فوه',
              },
              'dropoff'
            );
          }
        });
      }
    }

    // 4. Courier Live Position Marker (Orange motorcycle with pulse ring)
    if (courierLocation) {
      boundsPoints.push(courierLocation);
      const courierHtml = `
        <div class="relative flex items-center justify-center">
          <div class="absolute w-12 h-12 rounded-full bg-amber-500/30 pulsing-courier-ring"></div>
          <div class="relative w-10 h-10 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-xl border-2 border-white ring-2 ring-amber-400">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div class="absolute -bottom-6 bg-amber-900 text-white text-[10px] px-2 py-0.5 rounded shadow font-bold whitespace-nowrap">
            ${courierInfo?.name ? courierInfo.name.split(' ')[1] || 'الكابتن' : 'الكابتن في الطريق'}
          </div>
        </div>
      `;
      const courierIcon = L.divIcon({
        html: courierHtml,
        iconSize: [40, 40],
        iconAnchor: [20, 20],
      });
      const courierMarker = L.marker(courierLocation, { icon: courierIcon }).addTo(layer);
      courierMarker.bindPopup(`
        <div dir="rtl" class="text-right p-1.5 font-['Cairo']">
          <span class="text-[10px] text-amber-600 font-bold">مندوب فوه إكسبريس</span>
          <p class="font-bold text-slate-900 text-sm mt-0.5">${courierInfo?.name || 'كابتن التوصيل'}</p>
          <p class="text-xs text-slate-600">${courierInfo?.vehicle || 'دراجة نارية'}</p>
          <p class="text-xs text-emerald-700 font-semibold mt-1">الموقع مباشر في شوارع فوه</p>
        </div>
      `);
    }

    // 5. Draw connecting Route Polyline
    const routeCoords: [number, number][] = [];
    if (courierLocation) {
      routeCoords.push(courierLocation);
    } else if (pickupLocation) {
      routeCoords.push([pickupLocation.lat, pickupLocation.lng]);
    }

    if (pickupLocation && courierLocation) {
      // route via pickup or straight to dropoff
      routeCoords.push([pickupLocation.lat, pickupLocation.lng]);
    }

    if (dropoffLocation) {
      routeCoords.push([dropoffLocation.lat, dropoffLocation.lng]);
    }

    if (routeCoords.length >= 2) {
      routeLineRef.current = L.polyline(routeCoords, {
        color: '#059669', // Emerald line
        weight: 4,
        opacity: 0.85,
        dashArray: '8, 8',
      }).addTo(map);
    }

    // Auto-fit bounds if we have points and in tracking or full order mode
    if (boundsPoints.length > 1 && (mode === 'track_order' || pickupLocation || dropoffLocation)) {
      map.fitBounds(boundsPoints, { padding: [60, 60], maxZoom: 16 });
    }
  }, [pickupLocation, dropoffLocation, courierLocation, courierInfo, mode, showLandmarks, activePickerTarget]);

  // Geolocation button
  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      alert('خدمة تحديد الموقع غير مفعلة على متصفحك');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        if (mapInstanceRef.current) {
          mapInstanceRef.current.flyTo([latitude, longitude], 16, { duration: 1.5 });
          const userPoint: LocationPoint = {
            lat: latitude,
            lng: longitude,
            name: 'موقعي الحالي في فوه',
            district: 'فوه',
            details: 'تم التحديد بواسطة GPS',
          };
          if (onSelectLocation) {
            onSelectLocation(userPoint, activePickerTarget);
          }
        }
      },
      () => {
        // Fallback to Fuwwah center if blocked
        if (mapInstanceRef.current) {
          mapInstanceRef.current.flyTo(FUWWAH_CENTER, 16);
        }
      }
    );
  };

  // Landmark search
  const filteredLandmarks = searchQuery.trim()
    ? FUWWAH_LANDMARKS.filter(
        (lm) =>
          lm.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (lm.district && lm.district.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  const handleSelectLandmark = (lm: LocationPoint) => {
    setSelectedLandmark(lm.name);
    setSearchQuery('');
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([lm.lat, lm.lng], 16, { duration: 1.2 });
    }
    if (onSelectLocation) {
      onSelectLocation(lm, activePickerTarget);
    }
  };

  return (
    <div className="relative w-full overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 shadow-sm">
      {/* Top Map Controls Bar */}
      <div className="absolute top-3 right-3 left-3 z-[1000] flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        {/* Search Landmark Bar */}
        <div className="relative pointer-events-auto flex-1 min-w-[200px] max-w-sm">
          <div className="relative flex items-center">
            <Search className="absolute right-3 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن معلم في فوه (القنائي، النميري، البحر...)"
              className="w-full h-10 pr-9 pl-3 text-xs bg-white/95 backdrop-blur-md rounded-xl border border-slate-200 shadow-md text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
            />
          </div>

          {/* Autocomplete Results */}
          {filteredLandmarks.length > 0 && (
            <div className="absolute top-12 right-0 left-0 bg-white/98 rounded-xl shadow-xl border border-slate-200 overflow-hidden z-50 max-h-56 overflow-y-auto">
              {filteredLandmarks.map((lm, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectLandmark(lm)}
                  className="w-full text-right px-3 py-2.5 hover:bg-emerald-50 border-b border-slate-100 text-xs flex items-center justify-between transition-colors"
                >
                  <div>
                    <p className="font-bold text-slate-800">{lm.name}</p>
                    <p className="text-[11px] text-slate-500">{lm.district} - {lm.details}</p>
                  </div>
                  <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action Buttons: Pick target selector & Locate Me */}
        <div className="pointer-events-auto flex items-center gap-2">
          {(mode === 'pick_dropoff' || mode === 'pick_pickup' || mode === 'explore') && onSelectLocation && (
            <div className="bg-white/95 backdrop-blur-md p-1 rounded-xl shadow-md border border-slate-200 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setActivePickerTarget('dropoff')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  activePickerTarget === 'dropoff'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                موقع التسليم
              </button>
              <button
                type="button"
                onClick={() => setActivePickerTarget('pickup')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  activePickerTarget === 'pickup'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                موقع الاستلام
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={handleLocateMe}
            title="تحديد موقعي بنظام GPS"
            className="w-10 h-10 bg-white/95 backdrop-blur-md rounded-xl shadow-md border border-slate-200 flex items-center justify-center text-slate-700 hover:text-emerald-600 hover:bg-slate-50 transition-colors"
          >
            <Crosshair className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Map Container */}
      <div ref={mapContainerRef} className={`w-full ${heightClass}`} />

      {/* Bottom Floating Hint / Info Bar */}
      <div className="absolute bottom-3 right-3 left-3 z-[1000] pointer-events-none">
        <div className="bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-xl shadow-md border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-700">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
            <span className="font-semibold text-slate-900">خريطة مدينة فوه وقراها</span>
            <span className="text-slate-400" aria-hidden="true">·</span>
            <span className="text-slate-500">انقر على أي نقطة لتحديد الموقع بدقة</span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-600 font-medium">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span> استلام
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-blue-600"></span> تسليم
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span> المندوب
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
