import React, { useState, useEffect } from 'react';
import { Order, OrderStatus } from '../types';
import { InteractiveMap } from './InteractiveMap';
import {
  CheckCircle2,
  Clock,
  Phone,
  MessageCircle,
  Bike,
  ShieldCheck,
  MapPin,
  Package,
  RotateCw,
  Sparkles,
  ExternalLink,
  ChevronRight,
  ArrowRight,
} from 'lucide-react';

interface OrderTrackingViewProps {
  order: Order;
  onUpdateStatus?: (newStatus: OrderStatus) => void;
  onBackToMain?: () => void;
}

export const OrderTrackingView: React.FC<OrderTrackingViewProps> = ({
  order,
  onUpdateStatus,
  onBackToMain,
}) => {
  // Live courier coordinates on Fuwwah streets
  const [courierPos, setCourierPos] = useState<[number, number]>(
    order.currentCourierLocation || [order.pickupLocation.lat, order.pickupLocation.lng]
  );
  const [eta, setEta] = useState<number>(order.etaMinutes || 12);
  const [isSimulating, setIsSimulating] = useState(false);

  // Status steps definition
  const steps: { status: OrderStatus; title: string; desc: string }[] = [
    {
      status: 'confirmed',
      title: 'تم استلام وتأكيد الطلب',
      desc: 'تم تسجيل الطلب في فوه وتوجيهه للتنفيذ',
    },
    {
      status: 'preparing',
      title: order.type === 'parcel_shipment' ? 'تجهيز واستلام الطرد' : 'قيد التجهيز في المتجر',
      desc: order.type === 'parcel_shipment' ? 'المندوب يستلم الطرد من نقطة الاستلام' : 'المتجر يجهز الأصناف بعناية',
    },
    {
      status: 'on_the_way',
      title: 'المندوب في الطريق إليك',
      desc: 'الكابتن يتحرك الآن في شوارع فوه نحو موقع التسليم',
    },
    {
      status: 'arrived',
      title: 'الكابتن وصل أمام العنوان',
      desc: 'المندوب متواجد حالياً أمام موقع التسليم لتسليم الشحنة',
    },
    {
      status: 'delivered',
      title: 'تم التسليم بنجاح',
      desc: 'تم إدخال كود الأمان واستلام الطلب بنجاح',
    },
  ];

  const getStatusIndex = (st: OrderStatus) => {
    switch (st) {
      case 'pending_payment':
      case 'confirmed':
        return 0;
      case 'preparing':
      case 'courier_assigned':
        return 1;
      case 'on_the_way':
        return 2;
      case 'arrived':
        return 3;
      case 'delivered':
        return 4;
      default:
        return 0;
    }
  };

  const currentStepIndex = getStatusIndex(order.status);

  // Smooth Courier Movement Simulation across Fuwwah streets
  useEffect(() => {
    if (!isSimulating) return;

    const startLat = order.pickupLocation.lat;
    const startLng = order.pickupLocation.lng;
    const destLat = order.dropoffLocation.lat;
    const destLng = order.dropoffLocation.lng;

    let progress = 0;
    const interval = setInterval(() => {
      progress += 0.05;
      if (progress >= 1) {
        setCourierPos([destLat, destLng]);
        setEta(0);
        setIsSimulating(false);
        if (onUpdateStatus) {
          onUpdateStatus('arrived');
        }
        clearInterval(interval);
      } else {
        const currentLat = startLat + (destLat - startLat) * progress;
        const currentLng = startLng + (destLng - startLng) * progress;
        setCourierPos([currentLat, currentLng]);
        setEta(Math.max(1, Math.round((1 - progress) * 12)));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isSimulating, order.pickupLocation, order.dropoffLocation]);

  const courier = order.courier;

  return (
    <div className="space-y-6">
      {/* Top Banner Navigation */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {onBackToMain && (
            <button
              onClick={onBackToMain}
              className="p-2 text-slate-500 hover:text-slate-900 rounded-xl hover:bg-slate-100 transition-colors"
              title="العودة"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400">رقم التتبع:</span>
              <span className="font-mono text-sm font-black text-slate-900 bg-slate-100 px-2.5 py-0.5 rounded-lg border border-slate-200">
                {order.trackingNumber}
              </span>
              <span className="text-[11px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                {order.type === 'parcel_shipment' ? 'شحن طرد' : 'طلب من متجر'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {order.type === 'parcel_shipment'
                ? `طرد: ${order.parcelDetails?.category} (${order.parcelDetails?.weight})`
                : `المتجر: ${order.storeName || 'متجر فوه'}`}
            </p>
          </div>
        </div>

        {/* ETA & Simulation Button */}
        <div className="flex items-center gap-3">
          <div className="text-left bg-slate-50 px-4 py-2 rounded-xl border border-slate-200">
            <span className="text-[10px] text-slate-500 block font-semibold">الوقت المتبقي للوصول:</span>
            <span className="text-lg font-black text-emerald-700 tabular-nums">
              {order.status === 'delivered' ? 'تم التسليم' : `${eta} دقيقة`}
            </span>
          </div>

          <button
            type="button"
            onClick={() => {
              setIsSimulating(true);
              if (onUpdateStatus && order.status !== 'on_the_way') {
                onUpdateStatus('on_the_way');
              }
            }}
            disabled={isSimulating || order.status === 'delivered'}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 text-xs font-bold rounded-xl shadow-sm transition-all flex items-center gap-1.5"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : ''}`} />
            <span>{isSimulating ? 'جاري تحرك المندوب...' : 'محاكاة حركة المندوب في فوه'}</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Interactive Map with Courier vs Status & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Map View (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-4 border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
              <h3 className="text-xs font-bold text-slate-900">
                موقع المندوب المباشر في شوارع فوه (كفر الشيخ)
              </h3>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">
              GPS Live: {courierPos[0].toFixed(4)}, {courierPos[1].toFixed(4)}
            </span>
          </div>

          <InteractiveMap
            mode="track_order"
            pickupLocation={order.pickupLocation}
            dropoffLocation={order.dropoffLocation}
            courierLocation={courierPos}
            courierInfo={courier}
            heightClass="h-[440px]"
            showLandmarks={false}
          />

          {/* Quick Route Leg details */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-3 bg-emerald-50/70 border border-emerald-100 rounded-xl text-xs space-y-1">
              <span className="text-[10px] text-emerald-800 font-bold block">نقطة الاستلام:</span>
              <p className="font-bold text-slate-900 truncate">{order.pickupLocation.name}</p>
              <p className="text-[11px] text-slate-500 truncate">{order.pickupLocation.district || 'فوه'}</p>
            </div>

            <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl text-xs space-y-1">
              <span className="text-[10px] text-blue-800 font-bold block">موقع التسليم:</span>
              <p className="font-bold text-slate-900 truncate">{order.dropoffLocation.name}</p>
              <p className="text-[11px] text-slate-500 truncate">{order.dropoffLocation.details || order.dropoffLocation.district || 'فوه'}</p>
            </div>
          </div>
        </div>

        {/* Status Stepper & Details (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Status Stepper Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center justify-between">
              <span>مراحل تتبع الشحنة</span>
              <span className="text-xs text-emerald-600 font-semibold">مباشر ⚡</span>
            </h3>

            <div className="relative pl-2 pr-1 space-y-5">
              {steps.map((st, idx) => {
                const isCompleted = idx < currentStepIndex;
                const isCurrent = idx === currentStepIndex;
                const isPending = idx > currentStepIndex;

                return (
                  <div key={st.status} className="relative flex items-start gap-3">
                    {/* Connecting line */}
                    {idx < steps.length - 1 && (
                      <div
                        className={`absolute right-3.5 top-7 bottom-0 w-0.5 -mb-5 ${
                          idx < currentStepIndex ? 'bg-emerald-500' : 'bg-slate-200'
                        }`}
                      />
                    )}

                    {/* Step Icon */}
                    <div
                      className={`relative z-10 w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-bold transition-all ${
                        isCompleted
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : isCurrent
                          ? 'bg-slate-900 text-white ring-4 ring-emerald-100'
                          : 'bg-slate-100 text-slate-400'
                      }`}
                    >
                      {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                    </div>

                    {/* Step Content */}
                    <div className="space-y-0.5">
                      <p
                        className={`text-xs font-bold ${
                          isCurrent
                            ? 'text-slate-900 font-extrabold text-sm'
                            : isCompleted
                            ? 'text-slate-800'
                            : 'text-slate-400'
                        }`}
                      >
                        {st.title}
                      </p>
                      <p className="text-[11px] text-slate-500 leading-relaxed">{st.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick Status Advance for testing */}
            {onUpdateStatus && (
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400">تحديث يدوي للمرحلة:</span>
                <div className="flex gap-1">
                  {(['confirmed', 'preparing', 'on_the_way', 'arrived', 'delivered'] as OrderStatus[]).map((s) => (
                    <button
                      key={s}
                      onClick={() => onUpdateStatus(s)}
                      className={`px-2 py-1 text-[10px] rounded font-bold transition-colors ${
                        order.status === s
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {s === 'confirmed' ? 'تأكيد' : s === 'preparing' ? 'تجهيز' : s === 'on_the_way' ? 'بالطريق' : s === 'arrived' ? 'وصل' : 'تم'}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Courier Card */}
          {courier && (
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center font-bold text-lg shadow-md">
                    {courier.name.split(' ')[1]?.[0] || 'ك'}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{courier.name}</h4>
                    <p className="text-[11px] text-slate-500">{courier.vehicle} · {courier.plateNumber}</p>
                  </div>
                </div>

                <div className="text-left">
                  <span className="text-xs bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded font-bold">
                    ★ {courier.rating}
                  </span>
                </div>
              </div>

              {/* Call & WhatsApp actions */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <a
                  href={`tel:${courier.phone}`}
                  className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>اتصال هاتفي</span>
                </a>

                <a
                  href={`https://wa.me/${courier.whatsapp}?text=${encodeURIComponent(`أهلاً كابتن، بخصوص طلبي في فوه رقم ${order.trackingNumber}`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span>محادثة واتساب</span>
                </a>
              </div>
            </div>
          )}

          {/* Delivery Security OTP Code Card */}
          <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white rounded-3xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <span className="text-xs font-bold text-emerald-300">كود أمان استلام الشحنة (OTP)</span>
              </div>
              <span className="text-[10px] text-slate-300">اعطه للمندوب فقط عند الاستلام</span>
            </div>

            <div className="text-center py-2 bg-white/10 rounded-2xl border border-white/20">
              <span className="font-mono text-3xl font-black tracking-widest text-emerald-300">
                {order.deliveryCode}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-300 pt-1">
              <span>طريقة الدفع:</span>
              <span className="font-bold text-white">
                {order.paymentMethod === 'instapay'
                  ? 'انستا باي (مدفوع ✓)'
                  : order.paymentMethod === 'vodafone_cash'
                  ? 'فودافون كاش (مدفوع ✓)'
                  : order.paymentMethod === 'cod'
                  ? `كاش عند الاستلام (${order.total} ج.م)`
                  : 'محفظة إلكترونية'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
