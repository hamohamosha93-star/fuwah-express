import React from 'react';
import { Role } from '../types';

interface NavbarProps {
  currentRole: Role;
  onSelectRole: (role: Role) => void;
  activeTab: 'stores' | 'parcel' | 'tracking' | 'merchant' | 'courier';
  onSelectTab: (tab: 'stores' | 'parcel' | 'tracking' | 'merchant' | 'courier') => void;
  activeOrdersCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onSelectRole,
  activeTab,
  onSelectTab,
  activeOrdersCount,
}) => {
  return (
    <header className="sticky top-0 z-[1100] bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single Text Element) */}
        <button
          type="button"
          onClick={() => {
            onSelectRole('customer');
            onSelectTab('stores');
          }}
          className="text-lg font-black tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-emerald-700 transition-colors"
        >
          فوه إكسبريس
        </button>

        {/* Zone 2: 4-5 Concise Single-line Nav Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-bold text-slate-600">
          <button
            type="button"
            onClick={() => {
              onSelectRole('customer');
              onSelectTab('stores');
            }}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-slate-900 ${
              activeTab === 'stores' && currentRole === 'customer'
                ? 'text-emerald-700 border-b-2 border-emerald-600 pb-1'
                : ''
            }`}
          >
            متاجر فوه
          </button>

          <button
            type="button"
            onClick={() => {
              onSelectRole('customer');
              onSelectTab('parcel');
            }}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-slate-900 ${
              activeTab === 'parcel' && currentRole === 'customer'
                ? 'text-emerald-700 border-b-2 border-emerald-600 pb-1'
                : ''
            }`}
          >
            شحن الطرود
          </button>

          <button
            type="button"
            onClick={() => {
              onSelectTab('tracking');
            }}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-slate-900 flex items-center gap-1.5 ${
              activeTab === 'tracking'
                ? 'text-emerald-700 border-b-2 border-emerald-600 pb-1'
                : ''
            }`}
          >
            <span>تتبع الشحنات</span>
            {activeOrdersCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              onSelectRole('merchant');
              onSelectTab('merchant');
            }}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-slate-900 ${
              currentRole === 'merchant'
                ? 'text-emerald-700 border-b-2 border-emerald-600 pb-1'
                : ''
            }`}
          >
            بوابة التجار
          </button>

          <button
            type="button"
            onClick={() => {
              onSelectRole('courier');
              onSelectTab('courier');
            }}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-slate-900 ${
              currentRole === 'courier'
                ? 'text-emerald-700 border-b-2 border-emerald-600 pb-1'
                : ''
            }`}
          >
            كابتن التوصيل
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => {
              onSelectRole('customer');
              onSelectTab('parcel');
            }}
            className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-all shadow-sm whitespace-nowrap shrink-0 active:scale-95"
          >
            شحن طرد فوري
          </button>
        </div>
      </div>
    </header>
  );
};
