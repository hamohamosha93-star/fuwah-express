import React, { useState } from 'react';
import { PaymentMethodType } from '../types';
import { CheckCircle2, Copy, Check, ArrowRight, ShieldCheck, QrCode, Smartphone, Banknote, AlertCircle, UploadCloud } from 'lucide-react';
import confetti from 'canvas-confetti';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  orderTitle: string;
  orderNumber: string;
  onPaymentComplete: (method: PaymentMethodType, reference: string) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  amount,
  orderTitle,
  orderNumber,
  onPaymentComplete,
}) => {
  const [activeMethod, setActiveMethod] = useState<PaymentMethodType>('instapay');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // InstaPay fields
  const instapayHandle = 'fuwwah.express@instapay';
  const instapayName = 'فوه إكسبريس - شركة التوصيل والخدمات';
  const [instapayRef, setInstapayRef] = useState('');
  const [screenshotAttached, setScreenshotAttached] = useState(false);

  // Wallet fields
  const [selectedWalletNetwork, setSelectedWalletNetwork] = useState<'vodafone' | 'orange' | 'etisalat' | 'we'>('vodafone');
  const walletNumbers = {
    vodafone: '01023456789',
    orange: '01223456789',
    etisalat: '01123456789',
    we: '01523456789',
  };
  const [senderWalletPhone, setSenderWalletPhone] = useState('');
  const [walletTransactionCode, setWalletTransactionCode] = useState('');

  // COD fields
  const [codNeedChange, setCodNeedChange] = useState<string>('exact');

  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2500);
  };

  // USSD helper for Egypt wallets
  const getUssdCode = () => {
    const num = walletNumbers[selectedWalletNetwork];
    switch (selectedWalletNetwork) {
      case 'vodafone':
        return `*9*7*${num}*${amount}#`;
      case 'orange':
        return `*115*1*${num}*${amount}#`;
      case 'etisalat':
        return `*777*${num}*${amount}#`;
      case 'we':
        return `*322*${num}*${amount}#`;
    }
  };

  const handleConfirmPayment = () => {
    setErrorMessage(null);

    if (activeMethod === 'instapay') {
      if (!instapayRef.trim() && !screenshotAttached) {
        setErrorMessage('برجاء كتابة الرقم المرجعي للتحويل في انستا باي أو تأكيد إرفاق الإيصال');
        return;
      }
    } else if (activeMethod === 'vodafone_cash' || activeMethod === 'orange_cash' || activeMethod === 'etisalat_cash' || activeMethod === 'we_pay') {
      if (!senderWalletPhone.trim() || senderWalletPhone.length < 10) {
        setErrorMessage('برجاء إدخال رقم المحفظة التي تم التحويل منها بشكل صحيح');
        return;
      }
    }

    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore
      }

      const generatedRef =
        activeMethod === 'instapay'
          ? (instapayRef.trim() || `IPN-${Math.floor(100000 + Math.random() * 900000)}`)
          : activeMethod === 'cod'
          ? 'COD-PAY-ON-ARRIVAL'
          : `${selectedWalletNetwork.toUpperCase()}-${walletTransactionCode || Math.floor(100000 + Math.random() * 900000)}`;

      onPaymentComplete(activeMethod, generatedRef);
    }, 1200);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6 transition-all">
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 pb-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span className="text-xs font-semibold text-emerald-400">بوابة الدفع الآمن - فوه إكسبريس</span>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white text-xs font-bold px-2 py-1 rounded-md hover:bg-slate-800 transition-colors"
            >
              إلغاء
            </button>
          </div>

          <div className="flex items-baseline justify-between">
            <div>
              <h3 className="text-xl font-bold tracking-tight">{orderTitle}</h3>
              <p className="text-xs text-slate-400 mt-0.5">رقم الطلب: {orderNumber}</p>
            </div>
            <div className="text-left">
              <span className="text-2xl font-black text-emerald-400 tabular-nums">{amount}</span>
              <span className="text-xs text-slate-300 mr-1.5 font-bold">جنيه مصري</span>
            </div>
          </div>
        </div>

        {/* Payment Method Selector Tabs */}
        <div className="grid grid-cols-3 p-2 bg-slate-100 gap-1.5 border-b border-slate-200">
          <button
            type="button"
            onClick={() => setActiveMethod('instapay')}
            className={`py-2.5 px-3 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all ${
              activeMethod === 'instapay'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200 ring-2 ring-emerald-500/30'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <div className="w-6 h-6 rounded-lg bg-pink-100 text-pink-700 flex items-center justify-center font-black text-[11px]">
              IPN
            </div>
            <span>انستا باي (InstaPay)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveMethod('vodafone_cash')}
            className={`py-2.5 px-3 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all ${
              activeMethod !== 'instapay' && activeMethod !== 'cod'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200 ring-2 ring-emerald-500/30'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <Smartphone className="w-5 h-5 text-red-600" />
            <span>المحافظ الإلكترونية</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveMethod('cod')}
            className={`py-2.5 px-3 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all ${
              activeMethod === 'cod'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200 ring-2 ring-emerald-500/30'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <Banknote className="w-5 h-5 text-emerald-600" />
            <span>كاش عند الاستلام</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 space-y-5">
          {/* 1. INSTAPAY */}
          {activeMethod === 'instapay' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-4 border border-purple-100 flex items-start gap-4">
                <div className="w-20 h-20 bg-white p-1 rounded-xl shadow-sm border border-purple-200 flex items-center justify-center shrink-0">
                  <div className="text-center">
                    <QrCode className="w-12 h-12 text-purple-700 mx-auto" />
                    <span className="text-[9px] font-bold text-slate-600 block">امسح للدفع</span>
                  </div>
                </div>
                <div className="space-y-1.5 flex-1">
                  <span className="text-[11px] font-bold text-purple-800 uppercase tracking-wide">
                    الدفع اللحظي عبر تطبيق انستا باي الرسمي
                  </span>
                  <div className="flex items-center justify-between bg-white px-3 py-1.5 rounded-lg border border-purple-200">
                    <div>
                      <p className="text-[10px] text-slate-500">عنوان الدفع اللحظي (IPA):</p>
                      <p className="font-mono font-bold text-xs text-purple-900">{instapayHandle}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(instapayHandle, 'ipa')}
                      className="text-xs text-purple-700 hover:text-purple-900 flex items-center gap-1 font-semibold"
                    >
                      {copiedText === 'ipa' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                      <span className="text-[11px]">{copiedText === 'ipa' ? 'تم النسخ' : 'نسخ'}</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-600">اسم المستلم: <strong className="text-slate-900">{instapayName}</strong></p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  الرقم المرجعي للتحويل في انستا باي (Reference / Ref ID)
                </label>
                <input
                  type="text"
                  placeholder="مثال: 123456789012 أو رقم العملية"
                  value={instapayRef}
                  onChange={(e) => setInstapayRef(e.target.value)}
                  className="w-full h-11 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono"
                />
              </div>

              <div className="border border-dashed border-slate-300 rounded-xl p-3 flex items-center justify-between bg-slate-50">
                <div className="flex items-center gap-2">
                  <UploadCloud className="w-5 h-5 text-slate-500" />
                  <div>
                    <p className="text-xs font-bold text-slate-800">إرفاق إيصال الدفع أو لقطة الشاشة</p>
                    <p className="text-[11px] text-slate-500">للتأكيد الفوري بواسطة نظام فوه إكسبريس</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setScreenshotAttached(!screenshotAttached)}
                  className={`text-xs px-3 py-1.5 rounded-lg font-bold transition-colors ${
                    screenshotAttached
                      ? 'bg-emerald-600 text-white'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {screenshotAttached ? 'تم إرفاق الإيصال ✓' : 'إرفاق الإيصال'}
                </button>
              </div>
            </div>
          )}

          {/* 2. ELECTRONIC WALLETS */}
          {activeMethod !== 'instapay' && activeMethod !== 'cod' && (
            <div className="space-y-4">
              {/* Wallet Network Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  اختر شبكة المحفظة الإلكترونية:
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'vodafone', name: 'فودافون كاش', color: 'text-red-600 border-red-200 bg-red-50/50' },
                    { id: 'orange', name: 'أورنج كاش', color: 'text-orange-600 border-orange-200 bg-orange-50/50' },
                    { id: 'etisalat', name: 'اتصالات كاش', color: 'text-emerald-600 border-emerald-200 bg-emerald-50/50' },
                    { id: 'we', name: 'وي باي WE', color: 'text-indigo-600 border-indigo-200 bg-indigo-50/50' },
                  ].map((net) => (
                    <button
                      key={net.id}
                      type="button"
                      onClick={() => {
                        setSelectedWalletNetwork(net.id as any);
                        setActiveMethod(`${net.id}_cash` as PaymentMethodType);
                      }}
                      className={`p-2 rounded-xl text-center border text-xs font-bold transition-all ${
                        selectedWalletNetwork === net.id
                          ? 'border-slate-900 bg-slate-900 text-white shadow-sm'
                          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {net.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Wallet Transfer Details Box */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-500">رقم المحفظة المعتمد للتحويل:</span>
                    <p className="font-mono font-black text-base text-slate-900 tracking-wider">
                      {walletNumbers[selectedWalletNetwork]}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(walletNumbers[selectedWalletNetwork], 'wallet')}
                    className="px-3 py-1.5 text-xs bg-white rounded-lg border border-slate-300 font-semibold text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                  >
                    {copiedText === 'wallet' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedText === 'wallet' ? 'تم النسخ' : 'نسخ الرقم'}</span>
                  </button>
                </div>

                {/* USSD quick helper */}
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500">كود التحويل المباشر من الهاتف:</span>
                    <p className="font-mono font-bold text-slate-800 dir-ltr text-right">{getUssdCode()}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(getUssdCode(), 'ussd')}
                    className="text-[11px] font-semibold text-emerald-700 hover:underline"
                  >
                    {copiedText === 'ussd' ? 'تم نسخ الكود' : 'نسخ كود الاتصال'}
                  </button>
                </div>
              </div>

              {/* Sender Details Form */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    رقم المحفظة التي قمت بالتحويل منها *
                  </label>
                  <input
                    type="tel"
                    placeholder="مثال: 01012345678"
                    value={senderWalletPhone}
                    onChange={(e) => setSenderWalletPhone(e.target.value)}
                    className="w-full h-11 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    رقم العملية أو كود رسالة التأكيد
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: 948123 (اختياري)"
                    value={walletTransactionCode}
                    onChange={(e) => setWalletTransactionCode(e.target.value)}
                    className="w-full h-11 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 3. CASH ON DELIVERY */}
          {activeMethod === 'cod' && (
            <div className="space-y-4">
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-emerald-900">الدفع نقداً للمندوب عند استلام الشحنة في فوه</h4>
                  <p className="text-[11px] text-emerald-800">
                    ستقوم بدفع المبلغ الإجمالي (<strong className="tabular-nums font-mono">{amount} ج.م</strong>) مباشرة لكابتن فوه إكسبريس عند استلام الطلب.
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  هل تحتاج إلى باقٍ من فئات نقدية كبيرة؟
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'exact', label: 'المبلغ بالضبط جاهز' },
                    { id: 'change_200', label: 'معي 200 ج.م أحتاج باقي' },
                    { id: 'change_500', label: 'معي 500 ج.م أحتاج باقي' },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setCodNeedChange(opt.id)}
                      className={`p-2.5 rounded-xl text-center border text-xs font-medium transition-all ${
                        codNeedChange === opt.id
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs p-3 rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={isProcessing}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100 transition-colors"
            >
              رجوع
            </button>
            <button
              type="button"
              onClick={handleConfirmPayment}
              disabled={isProcessing}
              className="px-6 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] rounded-xl shadow-md transition-all flex items-center gap-2"
            >
              {isProcessing ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                  <span>جاري تأكيد الدفع...</span>
                </>
              ) : (
                <>
                  <span>
                    {activeMethod === 'cod' ? 'تأكيد الطلب والدفع عند الاستلام' : 'تأكيد الدفع وإتمام الطلب'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
