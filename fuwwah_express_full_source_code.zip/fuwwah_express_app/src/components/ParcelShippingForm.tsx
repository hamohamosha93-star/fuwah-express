import React, { useState } from 'react';
import { LocationPoint, Order } from '../types';
import { FUWWAH_LANDMARKS } from '../data/fuwwahData';
import { InteractiveMap } from './InteractiveMap';
import { Package, MapPin, Phone, User, FileText, ArrowLeft, ShieldAlert, Sparkles, Navigation } from 'lucide-react';

interface ParcelShippingFormProps {
  onSubmitParcelOrder: (orderData: Partial<Order>) => void;
  onCancel: () => void;
}

export const ParcelShippingForm: React.FC<ParcelShippingFormProps> = ({
  onSubmitParcelOrder,
  onCancel,
}) => {
  // Step: 1 = Details & Locations, 2 = Review & Confirm
  const [step, setStep] = useState<1 | 2>(1);

  // Parcel info
  const [parcelCategory, setParcelCategory] = useState('كليم وسجاد فوه التراثي');
  const [parcelDescription, setParcelDescription] = useState('سجادة كليم يدوي صوف ملفوفة بأمان');
  const [parcelWeight, setParcelWeight] = useState('1 - 5 كجم');
  const [isFragile, setIsFragile] = useState(false);
  const [packageValueEgp, setPackageValueEgp] = useState<number>(500);

  // Sender & Recipient
  const [senderName, setSenderName] = useState('الحاج محمود الفوهي');
  const [senderPhone, setSenderPhone] = useState('01012345678');
  const [recipientName, setRecipientName] = useState('أحمد إبراهيم');
  const [recipientPhone, setRecipientPhone] = useState('01198765432');
  const [notes, setNotes] = useState('برجاء الاتصال بالمستلم قبل الوصول بـ 5 دقائق');

  // Locations
  const [pickupLocation, setPickupLocation] = useState<LocationPoint>(FUWWAH_LANDMARKS[3]); // ربع الخطايبة
  const [dropoffLocation, setDropoffLocation] = useState<LocationPoint>(FUWWAH_LANDMARKS[8]); // حي الدفراوي
  const [mapPickerTarget, setMapPickerTarget] = useState<'pickup' | 'dropoff'>('dropoff');

  // Calculate dynamic delivery fee in Fuwwah based on distance
  const calculateDistanceKm = (p1: LocationPoint, p2: LocationPoint) => {
    const R = 6371; // km
    const dLat = ((p2.lat - p1.lat) * Math.PI) / 180;
    const dLon = ((p2.lng - p1.lng) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((p1.lat * Math.PI) / 180) *
        Math.cos((p2.lat * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.max(0.8, Number((R * c).toFixed(1)));
  };

  const distanceKm = calculateDistanceKm(pickupLocation, dropoffLocation);
  // Base 15 EGP + 4 EGP per km
  const deliveryFee = Math.round(15 + distanceKm * 4);

  const handleSelectMapLocation = (point: LocationPoint, type: 'pickup' | 'dropoff') => {
    if (type === 'pickup') {
      setPickupLocation(point);
    } else {
      setDropoffLocation(point);
    }
  };

  const handleProceedToPayment = () => {
    const orderData: Partial<Order> = {
      type: 'parcel_shipment',
      customerName: senderName,
      customerPhone: senderPhone,
      recipientName,
      recipientPhone,
      pickupLocation,
      dropoffLocation,
      parcelDetails: {
        category: parcelCategory,
        description: parcelDescription,
        weight: parcelWeight,
        isFragile,
        packageValueEgp,
      },
      subtotal: 0,
      deliveryFee,
      total: deliveryFee,
      notes,
    };
    onSubmitParcelOrder(orderData);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">شحن وتوصيل الطرود داخل فوه وقراها</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              خدمة استلام الطرد من باب بيتك أو متجرك وتسليمه في أي مكان بمركز فوه مع تتبع لحظي
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-semibold">تكلفة التوصيل المقدرة:</span>
          <span className="text-xl font-black text-emerald-700 tabular-nums">{deliveryFee} ج.م</span>
          <span className="text-[11px] text-slate-400">({distanceKm} كم)</span>
        </div>
      </div>

      {/* Main Grid: Left Interactive Map, Right Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Map Column (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Navigation className="w-4 h-4 text-emerald-600" />
                <span>تحديد موقعي الاستلام والتسليم على خريطة فوه</span>
              </h3>
              <span className="text-[10px] text-slate-500 font-medium">انقر أو اسحب الدبوس</span>
            </div>

            <InteractiveMap
              mode={mapPickerTarget === 'pickup' ? 'pick_pickup' : 'pick_dropoff'}
              pickupLocation={pickupLocation}
              dropoffLocation={dropoffLocation}
              onSelectLocation={handleSelectMapLocation}
              heightClass="h-[360px]"
            />

            {/* Quick Landmark Presets */}
            <div className="pt-2">
              <p className="text-[11px] font-bold text-slate-600 mb-1.5">معالم فوه الشهيرة السريعة:</p>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                {FUWWAH_LANDMARKS.slice(0, 7).map((lm, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      if (mapPickerTarget === 'pickup') {
                        setPickupLocation(lm);
                      } else {
                        setDropoffLocation(lm);
                      }
                    }}
                    className="text-[10px] px-2 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 rounded-md text-slate-700 font-medium transition-colors"
                  >
                    + {lm.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Form Column (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-6">
          {/* Pickup & Dropoff Inputs */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-600" />
              <span>بيانات الاستلام والتسليم</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Pickup */}
              <div className="p-3.5 bg-emerald-50/50 rounded-xl border border-emerald-200/70 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-800 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-600"></span> نقطة الاستلام (من أين؟)
                  </span>
                  <button
                    type="button"
                    onClick={() => setMapPickerTarget('pickup')}
                    className={`text-[10px] font-bold px-2 py-0.5 rounded transition-colors ${
                      mapPickerTarget === 'pickup'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-white text-emerald-700 border border-emerald-300'
                    }`}
                  >
                    تحديد عالخريطة
                  </button>
                </div>
                <input
                  type="text"
                  value={pickupLocation.name}
                  onChange={(e) => setPickupLocation({ ...pickupLocation, name: e.target.value })}
                  placeholder="اسم المكان (منزل، متجر، ورشة...)"
                  className="w-full text-xs bg-white rounded-lg px-2.5 py-1.5 border border-emerald-200 font-semibold text-slate-900"
                />
                <input
                  type="text"
                  value={pickupLocation.details || ''}
                  onChange={(e) => setPickupLocation({ ...pickupLocation, details: e.target.value })}
                  placeholder="تفاصيل العنوان (الشارع، الدور، علامة مميزة)"
                  className="w-full text-xs bg-white rounded-lg px-2.5 py-1.5 border border-emerald-200 text-slate-700"
                />
              </div>

              {/* Dropoff */}
              <div className="p-3.5 bg-blue-50/50 rounded-xl border border-blue-200/70 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-blue-800 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-blue-600"></span> نقطة التسليم (إلى أين؟)
                  </span>
                  <button
                    type="button"
                    onClick={() => setMapPickerTarget('dropoff')}
                    className={`text-[10px] font-bold px-2 py-0.5 rounded transition-colors ${
                      mapPickerTarget === 'dropoff'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white text-blue-700 border border-blue-300'
                    }`}
                  >
                    تحديد عالخريطة
                  </button>
                </div>
                <input
                  type="text"
                  value={dropoffLocation.name}
                  onChange={(e) => setDropoffLocation({ ...dropoffLocation, name: e.target.value })}
                  placeholder="اسم الوجهة (منزل، عيادة، مدرسة...)"
                  className="w-full text-xs bg-white rounded-lg px-2.5 py-1.5 border border-blue-200 font-semibold text-slate-900"
                />
                <input
                  type="text"
                  value={dropoffLocation.details || ''}
                  onChange={(e) => setDropoffLocation({ ...dropoffLocation, details: e.target.value })}
                  placeholder="تفاصيل العنوان والمستلم"
                  className="w-full text-xs bg-white rounded-lg px-2.5 py-1.5 border border-blue-200 text-slate-700"
                />
              </div>
            </div>
          </div>

          {/* Parcel Specifications */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-2">
              <Package className="w-4 h-4 text-emerald-600" />
              <span>مواصفات الطرد والشحنة</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">نوع ومحتوى الطرد</label>
                <select
                  value={parcelCategory}
                  onChange={(e) => setParcelCategory(e.target.value)}
                  className="w-full h-10 px-3 text-xs rounded-xl border border-slate-200 bg-white font-medium focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="كليم وسجاد فوه التراثي">كليم وسجاد فوه التراثي ومنسوجات</option>
                  <option value="أوراق ومستندات هامة">أوراق ومستندات وعقود هامة</option>
                  <option value="حلويات ومأكولات طازجة">حلويات ومأكولات طازجة</option>
                  <option value="أدوية ومستلزمات علاجية">أدوية ومستلزمات صيدلية</option>
                  <option value="أجهزة إلكترونية وهواتف">أجهزة إلكترونية وهواتف</option>
                  <option value="ملابس وهدايا">ملابس وإكسسوارات وهدايا</option>
                  <option value="أخرى / شحنة تجارية">أخرى / شحنة تجارية خاصة</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">الوزن التقريبي</label>
                <select
                  value={parcelWeight}
                  onChange={(e) => setParcelWeight(e.target.value)}
                  className="w-full h-10 px-3 text-xs rounded-xl border border-slate-200 bg-white font-medium focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="أقل من 1 كجم">أقل من 1 كجم (خفيف / مظروف)</option>
                  <option value="1 - 5 كجم">1 - 5 كجم (طرد عادي / كرتونة)</option>
                  <option value="5 - 15 كجم">5 - 15 كجم (طرد متوسط / سجادة)</option>
                  <option value="15+ كجم">أكثر من 15 كجم (شحنة تروسيكل)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">وصف محتويات الشحنة بدقة</label>
              <input
                type="text"
                value={parcelDescription}
                onChange={(e) => setParcelDescription(e.target.value)}
                placeholder="مثال: قطعتين كليم فوه أزرق وهندسي مقاس 1.5 في 2 متر"
                className="w-full h-10 px-3 text-xs rounded-xl border border-slate-200 font-medium focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="flex items-center gap-6 pt-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isFragile}
                  onChange={(e) => setIsFragile(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                  قابل للكسر أو يحتاج عناية خاصة
                </span>
              </label>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-600 font-medium">قيمة الأمانة المقدرة:</span>
                <input
                  type="number"
                  value={packageValueEgp}
                  onChange={(e) => setPackageValueEgp(Number(e.target.value))}
                  className="w-24 h-8 px-2 text-xs rounded-lg border border-slate-200 font-mono font-bold"
                />
                <span className="text-xs text-slate-500">ج.م</span>
              </div>
            </div>
          </div>

          {/* Contact Details */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-600" />
              <span>أرقام التواصل والتسليم</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اسم المرسل</label>
                <input
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  className="w-full h-10 px-3 text-xs rounded-xl border border-slate-200 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">رقم هاتف المرسل</label>
                <input
                  type="tel"
                  value={senderPhone}
                  onChange={(e) => setSenderPhone(e.target.value)}
                  className="w-full h-10 px-3 text-xs rounded-xl border border-slate-200 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اسم المستلم</label>
                <input
                  type="text"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  className="w-full h-10 px-3 text-xs rounded-xl border border-slate-200 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">رقم هاتف المستلم (لتسليم كود الأمان)</label>
                <input
                  type="tel"
                  value={recipientPhone}
                  onChange={(e) => setRecipientPhone(e.target.value)}
                  className="w-full h-10 px-3 text-xs rounded-xl border border-slate-200 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ملاحظات إضافية للمندوب</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="مثال: يرجى الاتصال قبل الوصول بدقائق، التسليم للشخص نفسه"
                className="w-full h-10 px-3 text-xs rounded-xl border border-slate-200 text-slate-700"
              />
            </div>
          </div>

          {/* Pricing Summary & Action CTA */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-600">المسافة المقدرة: <strong className="text-slate-900">{distanceKm} كم</strong></span>
                <span className="text-slate-300" aria-hidden="true">·</span>
                <span className="text-xs text-slate-600">وقت التوصيل المتوقع: <strong className="text-slate-900">20-30 دقيقة</strong></span>
              </div>
              <p className="text-[11px] text-emerald-700 font-semibold mt-0.5">
                تأمين وحماية كاملة للطرد وضمان تسليم شخصي بكود OTP
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleProceedToPayment}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-2 active:scale-[0.98]"
              >
                <span>متابعة لاختيار الدفع (انستا باي / محافظ / كاش)</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
