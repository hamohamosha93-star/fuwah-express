import React, { useState } from 'react';
import { Order, Courier, OrderStatus } from '../types';
import { INITIAL_COURIERS } from '../data/fuwwahData';
import { InteractiveMap } from './InteractiveMap';
import { Bike, Phone, MessageCircle, Navigation, CheckCircle2, ShieldCheck, MapPin, DollarSign, Power } from 'lucide-react';

interface CourierDashboardProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
  onSelectTrackOrder: (order: Order) => void;
}

export const CourierDashboard: React.FC<CourierDashboardProps> = ({
  orders,
  onUpdateOrderStatus,
  onSelectTrackOrder,
}) => {
  const [currentCourier, setCurrentCourier] = useState<Courier>(INITIAL_COURIERS[0]);
  const [isOnline, setIsOnline] = useState(true);
  const [otpInputs, setOtpInputs] = useState<{ [orderId: string]: string }>({});
  const [otpError, setOtpError] = useState<{ [orderId: string]: string }>({});

  // Active delivery trips assigned to this courier or open in Fuwwah
  const activeTrips = orders.filter((o) => o.status !== 'delivered' && o.status !== 'cancelled');
  const completedTrips = orders.filter((o) => o.status === 'delivered');

  const totalEarnings = completedTrips.reduce((acc, o) => acc + o.deliveryFee, 0) + 180; // base + today's trips

  const handleVerifyOtpAndDeliver = (order: Order) => {
    const inputCode = otpInputs[order.id]?.trim();
    if (inputCode === order.deliveryCode) {
      onUpdateOrderStatus(order.id, 'delivered');
      setOtpError((prev) => ({ ...prev, [order.id]: '' }));
    } else {
      setOtpError((prev) => ({
        ...prev,
        [order.id]: 'كود الأمان غير مطابق! اطلب الكود من العميل أولاً',
      }));
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Courier Bar */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-14 h-14 rounded-2xl bg-amber-500 text-white flex items-center justify-center font-bold text-xl shadow-lg">
              {currentCourier.name.split(' ')[1]?.[0] || 'ك'}
            </div>
            <span
              className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-slate-900 ${
                isOnline ? 'bg-emerald-500' : 'bg-rose-500'
              }`}
            />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold">{currentCourier.name}</h2>
              <span className="text-xs bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-bold">
                ★ {currentCourier.rating}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              مركبة التوصيل: {currentCourier.vehicle} · {currentCourier.plateNumber}
            </p>
          </div>
        </div>

        {/* Online / Switcher */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setIsOnline(!isOnline)}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              isOnline
                ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Power className="w-4 h-4" />
            <span>{isOnline ? 'متاح لاستقبال شحنات في فوه' : 'غير متصل (استراحة)'}</span>
          </button>

          <select
            value={currentCourier.id}
            onChange={(e) => {
              const c = INITIAL_COURIERS.find((item) => item.id === e.target.value);
              if (c) setCurrentCourier(c);
            }}
            className="text-xs font-bold px-3 py-2 bg-slate-800 rounded-xl border border-slate-700 text-slate-200"
          >
            {INITIAL_COURIERS.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.vehicle.split(' ')[0]})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Courier Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500">أرباح اليوم التقديرية</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-emerald-700 tabular-nums">{totalEarnings}</span>
            <span className="text-xs text-slate-500 font-bold">جنيه مصري</span>
          </div>
          <span className="text-[11px] text-emerald-600 font-semibold block mt-1">
            شاملة رسوم التوصيل وعمولات المشاوير
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500">شحنات وطلبات في انتظارك</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-amber-600 tabular-nums">{activeTrips.length}</span>
            <span className="text-xs text-slate-500 font-bold">شحنة حالية</span>
          </div>
          <span className="text-[11px] text-slate-500 block mt-1">داخل نطاق فوه وكورنيش النيل</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500">الرحلات المكتملة</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-slate-900 tabular-nums">
              {completedTrips.length + 8}
            </span>
            <span className="text-xs text-slate-500 font-bold">رحلة ناجحة</span>
          </div>
          <span className="text-[11px] text-emerald-600 font-semibold block mt-1">
            نسبة الالتزام بالوقت 99%
          </span>
        </div>
      </div>

      {/* Active Trips List for the Captain */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Bike className="w-5 h-5 text-amber-500" />
          <span>الشحنات والطلبات المسندة إليك الآن في فوه</span>
        </h3>

        {activeTrips.length === 0 ? (
          <div className="bg-white rounded-3xl p-10 text-center border border-slate-200 text-slate-500 text-xs">
            لا توجد شحنات معلقة حالياً. سيتم إشعارك فور وصول طلب جديد من متاجر فوه أو طرود الزبائن.
          </div>
        ) : (
          <div className="space-y-4">
            {activeTrips.map((order) => (
              <div
                key={order.id}
                className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-black bg-slate-900 text-white px-2.5 py-1 rounded-lg">
                      {order.trackingNumber}
                    </span>
                    <span className="text-xs font-bold text-slate-800">
                      {order.type === 'parcel_shipment' ? 'طرد شخصي / أمانة' : order.storeName}
                    </span>
                    <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold border border-emerald-200">
                      أجرة التوصيل: {order.deliveryFee} ج.م
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onSelectTrackOrder(order)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold flex items-center gap-1"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>عرض على الخريطة التفاعلية</span>
                    </button>
                  </div>
                </div>

                {/* Pickup and Dropoff Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <span className="text-[10px] text-emerald-700 font-bold block">1. الاستلام من:</span>
                    <p className="text-xs font-bold text-slate-900">{order.pickupLocation.name}</p>
                    <p className="text-[11px] text-slate-500">{order.pickupLocation.details || order.pickupLocation.district}</p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <span className="text-[10px] text-blue-700 font-bold block">2. التسليم إلى:</span>
                    <p className="text-xs font-bold text-slate-900">{order.dropoffLocation.name}</p>
                    <p className="text-[11px] text-slate-500">{order.dropoffLocation.details || order.dropoffLocation.district}</p>
                  </div>
                </div>

                {/* Customer Contact & Payment Status */}
                <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
                  <div className="space-y-1">
                    <p className="text-xs text-slate-700">
                      العميل المستلم: <strong className="text-slate-900">{order.customerName}</strong>
                    </p>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-slate-500">حالة الدفع:</span>
                      <strong className="text-emerald-700">
                        {order.paymentMethod === 'instapay'
                          ? 'انستا باي (مدفوع رقمياً)'
                          : order.paymentMethod.includes('cash')
                          ? 'محفظة إلكترونية (مدفوع)'
                          : `تحصيل كاش من العميل (${order.total} ج.م)`}
                      </strong>
                    </div>
                  </div>

                  {/* Contact Buttons */}
                  <div className="flex items-center gap-2">
                    <a
                      href={`tel:${order.customerPhone}`}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>اتصال بالعميل</span>
                    </a>

                    <a
                      href={`https://wa.me/2${order.customerPhone.replace(/^0/, '')}?text=${encodeURIComponent(`أهلاً يا فندم، أنا كابتن فوه إكسبريس في الطريق إليك بالطلب رقم ${order.trackingNumber}`)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>واتساب</span>
                    </a>
                  </div>
                </div>

                {/* Handover & OTP Completion Box */}
                <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-amber-700" />
                    <div>
                      <p className="text-xs font-bold text-amber-950">إتمام التسليم وإدخال كود الأمان (OTP):</p>
                      <p className="text-[11px] text-amber-800">اطلب الكود المكون من 4 أرقام من العميل عند التسليم</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      maxLength={4}
                      placeholder="الكود 4 أرقام"
                      value={otpInputs[order.id] || ''}
                      onChange={(e) =>
                        setOtpInputs({ ...otpInputs, [order.id]: e.target.value })
                      }
                      className="w-28 h-10 text-center font-mono font-black text-sm bg-white rounded-xl border border-amber-300 tracking-widest focus:ring-2 focus:ring-amber-500"
                    />

                    <button
                      type="button"
                      onClick={() => handleVerifyOtpAndDeliver(order)}
                      className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-sm transition-all flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>تأكيد التسليم بنجاح</span>
                    </button>
                  </div>

                  {otpError[order.id] && (
                    <div className="w-full text-rose-600 text-xs font-bold pt-1">
                      {otpError[order.id]}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
