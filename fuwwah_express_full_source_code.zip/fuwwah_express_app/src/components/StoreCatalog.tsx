import React, { useState } from 'react';
import { Store, ProductItem, CartItem, LocationPoint, Order } from '../types';
import { INITIAL_STORES, FUWWAH_LANDMARKS } from '../data/fuwwahData';
import { Search, Star, Clock, ShoppingBag, Plus, Minus, Trash2, ArrowLeft, Check, Sparkles, MapPin } from 'lucide-react';

interface StoreCatalogProps {
  onCheckout: (cart: CartItem[], store: Store, dropoff: LocationPoint, notes: string) => void;
  onOpenParcelForm: () => void;
  onOpenApkModal?: () => void;
}

export const StoreCatalog: React.FC<StoreCatalogProps> = ({
  onCheckout,
  onOpenParcelForm,
  onOpenApkModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeStore, setActiveStore] = useState<Store | null>(null);

  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [dropoffPoint, setDropoffPoint] = useState<LocationPoint>(FUWWAH_LANDMARKS[0]);
  const [orderNotes, setOrderNotes] = useState('');

  // Categories list
  const categories = [
    { id: 'all', name: 'جميع المتاجر في فوه' },
    { id: 'restaurant', name: 'مطاعم وأسماك النيل' },
    { id: 'sweets', name: 'حلويات ومخابز' },
    { id: 'grocery', name: 'سوبرماركت وخضار طازج' },
    { id: 'kilim_craft', name: 'سجاد وكليم فوه التراثي' },
    { id: 'pharmacy', name: 'صيدليات وأدوية' },
  ];

  // Filtering
  const filteredStores = INITIAL_STORES.filter((st) => {
    const matchesCat = selectedCategory === 'all' || st.category === selectedCategory;
    const matchesSearch =
      st.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      st.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      st.products.some((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const addToCart = (product: ProductItem, store: Store) => {
    setCartItems((prev) => {
      // If adding from a different store, reset or prompt
      const currentStoreItem = prev.find((item) => item.storeId !== store.id);
      let workingCart = prev;
      if (currentStoreItem) {
        workingCart = []; // single store order flow
      }

      const existingIndex = workingCart.findIndex((item) => item.product.id === product.id);
      if (existingIndex > -1) {
        const next = [...workingCart];
        next[existingIndex].quantity += 1;
        return next;
      } else {
        return [...workingCart, { product, quantity: 1, storeId: store.id, storeName: store.name }];
      }
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const cartStore = cartItems.length > 0 ? INITIAL_STORES.find((s) => s.id === cartItems[0].storeId) : null;
  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const deliveryFee = cartStore?.deliveryFee || 15;
  const total = subtotal + (cartItems.length > 0 ? deliveryFee : 0);

  const handleStartCheckout = () => {
    if (!cartStore || cartItems.length === 0) return;
    onCheckout(cartItems, cartStore, dropoffPoint, orderNotes);
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner with Call to Action for Parcel and Local Shops */}
      <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white p-6 sm:p-8 lg:p-10 shadow-lg border border-slate-800">
        <div className="absolute inset-0 opacity-30 mix-blend-overlay">
          <img
            src="/src/assets/images/hero_fuwwah_delivery_1794089334616.jpg"
            alt="فوه إكسبريس"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-md">
            <span>محافظة كفر الشيخ · مدينة فوه التاريخية</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white leading-tight">
            أسرع دليفري وشحن طرود بين يديك في فوه
          </h1>

          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            اطلب من أشهر مطاعم أسماك النيل، محلات الحلويات، ورش الكليم والسجاد اليدوي بربع الخطايبة، أو أرسل أي طرد من باب بيتك إلى أي مكان في فوه بدفع فوري عبر انستا باي والمحافظ الإلكترونية.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenParcelForm}
              className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 active:scale-95"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>شحن طرد أو مشوار خاص</span>
            </button>
            {onOpenApkModal && (
              <button
                type="button"
                onClick={onOpenApkModal}
                className="px-4 py-2.5 bg-white text-slate-950 hover:bg-emerald-50 font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 active:scale-95"
              >
                <span>تثبيت وتحميل التطبيق (APK)</span>
              </button>
            )}
            <a
              href="#stores-section"
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-medium text-xs rounded-xl backdrop-blur-sm transition-colors border border-white/20"
            >
              تصفح متاجر فوه
            </a>
          </div>
        </div>
      </div>

      {/* Category Pills & Search Bar */}
      <div id="stores-section" className="space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute right-3.5 top-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن متجر، سمك مشوي، كنافة، كليم فوه، علاج..."
              className="w-full h-10 pr-10 pl-4 text-xs bg-white rounded-xl border border-slate-200 shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
            />
          </div>

          {/* Cart Trigger Badge Button */}
          {cartItems.length > 0 && (
            <button
              onClick={() => setIsCartOpen(true)}
              className="flex items-center gap-2.5 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md transition-all animate-pulse"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>سلة الطلب ({cartItems.reduce((sum, i) => sum + i.quantity, 0)})</span>
              <span className="font-mono tabular-nums bg-white/20 px-1.5 py-0.5 rounded text-[11px]">{total} ج.م</span>
            </button>
          )}
        </div>

        {/* Categories Tab Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Stores Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredStores.map((store) => (
          <div
            key={store.id}
            className="group bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              {/* Image banner */}
              <div className="relative h-44 w-full bg-slate-100 overflow-hidden">
                <img
                  src={store.image}
                  alt={store.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 right-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-full text-[11px] font-bold text-slate-800 shadow-sm flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span className="tabular-nums">{store.rating}</span>
                </div>
                <div className="absolute bottom-3 right-3 bg-slate-900/80 backdrop-blur-sm text-white px-2.5 py-1 rounded-lg text-[10px] font-medium flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{store.deliveryTimeMins}</span>
                </div>
              </div>

              {/* Store Details */}
              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-slate-900 text-base">{store.name}</h3>
                  <span className="text-[11px] text-emerald-700 font-semibold">{store.categoryAr}</span>
                </div>

                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {store.description}
                </p>

                <div className="flex items-center gap-2 text-[11px] text-slate-600 pt-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{store.address}</span>
                </div>
              </div>
            </div>

            {/* Products Preview & Store Action */}
            <div className="p-4 pt-0 border-t border-slate-100 mt-2 space-y-3">
              <div className="space-y-1.5 pt-2">
                <p className="text-[11px] font-bold text-slate-500">أبرز المنتجات والأصناف:</p>
                <div className="space-y-1">
                  {store.products.slice(0, 2).map((prod) => (
                    <div
                      key={prod.id}
                      className="flex items-center justify-between text-xs py-1 px-2 rounded-lg bg-slate-50 border border-slate-100"
                    >
                      <span className="font-semibold text-slate-800 truncate max-w-[180px]">{prod.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-emerald-700 tabular-nums">{prod.price} ج.م</span>
                        <button
                          type="button"
                          onClick={() => addToCart(prod, store)}
                          className="w-6 h-6 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md flex items-center justify-center transition-transform active:scale-90"
                          title="إضافة للسلة"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-slate-500">
                  توصيل: <strong className="text-slate-800">{store.deliveryFee} ج.م</strong>
                </span>
                <button
                  type="button"
                  onClick={() => setActiveStore(store)}
                  className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold transition-colors"
                >
                  عرض قائمة المتجر بالكامل ({store.products.length})
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Store Full Menu Modal */}
      {activeStore && (
        <div className="fixed inset-0 z-[1500] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="relative h-48 bg-slate-900">
              <img
                src={activeStore.image}
                alt={activeStore.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover opacity-60"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
              <button
                type="button"
                onClick={() => setActiveStore(null)}
                className="absolute top-4 left-4 bg-white/20 hover:bg-white/30 text-white rounded-full p-2 text-xs font-bold backdrop-blur-md"
              >
                ✕ إغلاق
              </button>
              <div className="absolute bottom-4 right-4 text-white">
                <h3 className="text-2xl font-black">{activeStore.name}</h3>
                <p className="text-xs text-slate-200 mt-0.5">{activeStore.address} · {activeStore.deliveryTimeMins}</p>
              </div>
            </div>

            <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
              <div className="space-y-3">
                {activeStore.products.map((prod) => (
                  <div
                    key={prod.id}
                    className="p-3.5 rounded-2xl border border-slate-200 hover:border-emerald-300 transition-colors flex items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-900 text-sm">{prod.name}</h4>
                        {prod.isPopular && (
                          <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded font-semibold border border-amber-200">
                            الأكثر طلباً في فوه
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 leading-relaxed">{prod.description}</p>
                      <p className="text-xs font-extrabold text-emerald-700 tabular-nums">{prod.price} جنيه مصري</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => addToCart(prod, activeStore)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm active:scale-95 shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>إضافة</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <div className="text-xs text-slate-600">
                رسوم التوصيل الموحدة داخل فوه: <strong className="text-slate-900">{activeStore.deliveryFee} ج.م</strong>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActiveStore(null);
                  setIsCartOpen(true);
                }}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold"
              >
                متابعة السلة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cart Drawer / Slide-Over */}
      {isCartOpen && (
        <div className="fixed inset-0 z-[1600] flex justify-end bg-slate-950/40 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between border-r border-slate-200">
            {/* Cart Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">سلة مشتريات فوه</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsCartOpen(false)}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800 p-1"
              >
                ✕ إغلاق
              </button>
            </div>

            {/* Cart Body */}
            <div className="p-5 overflow-y-auto space-y-5 flex-1">
              {cartItems.length === 0 ? (
                <div className="text-center py-12 text-slate-500 space-y-3">
                  <ShoppingBag className="w-12 h-12 mx-auto text-slate-300" />
                  <p className="text-sm font-semibold">السلة فارغة حالياً</p>
                  <p className="text-xs">تصفح متاجر فوه واختر ما تحتاجه ليصلك فوراً</p>
                </div>
              ) : (
                <>
                  {/* Store info banner */}
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100 flex items-center justify-between text-xs">
                    <span className="font-bold text-emerald-900">المتجر: {cartItems[0]?.storeName}</span>
                    <button
                      type="button"
                      onClick={() => setCartItems([])}
                      className="text-[11px] text-rose-600 hover:underline flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>تفريغ</span>
                    </button>
                  </div>

                  {/* Items list */}
                  <div className="space-y-3">
                    {cartItems.map((item) => (
                      <div
                        key={item.product.id}
                        className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200"
                      >
                        <div className="space-y-0.5">
                          <p className="font-bold text-slate-900 text-xs">{item.product.name}</p>
                          <p className="text-[11px] text-emerald-700 font-bold tabular-nums">
                            {item.product.price} ج.م × {item.quantity} = {item.product.price * item.quantity} ج.م
                          </p>
                        </div>
                        <div className="flex items-center gap-2 bg-white rounded-lg border border-slate-200 p-1">
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.product.id, -1)}
                            className="w-6 h-6 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="text-xs font-bold text-slate-900 px-1 font-mono tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.product.id, 1)}
                            className="w-6 h-6 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Delivery Location in Fuwwah */}
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <label className="block text-xs font-bold text-slate-800">
                      مكان التوصيل في فوه:
                    </label>
                    <select
                      value={dropoffPoint.name}
                      onChange={(e) => {
                        const target = FUWWAH_LANDMARKS.find((lm) => lm.name === e.target.value);
                        if (target) setDropoffPoint(target);
                      }}
                      className="w-full h-10 px-3 text-xs bg-white rounded-xl border border-slate-200 font-medium"
                    >
                      {FUWWAH_LANDMARKS.map((lm, idx) => (
                        <option key={idx} value={lm.name}>
                          {lm.name} ({lm.district})
                        </option>
                      ))}
                    </select>

                    <input
                      type="text"
                      placeholder="تفاصيل العنوان (الشارع، رقم العمارة، الشقة)"
                      value={dropoffPoint.details || ''}
                      onChange={(e) => setDropoffPoint({ ...dropoffPoint, details: e.target.value })}
                      className="w-full h-9 px-3 text-xs rounded-xl border border-slate-200"
                    />

                    <input
                      type="text"
                      placeholder="ملاحظات للطلب (مثال: بدون شطة، تسليم على الباب)"
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      className="w-full h-9 px-3 text-xs rounded-xl border border-slate-200 text-slate-600"
                    />
                  </div>
                </>
              )}
            </div>

            {/* Cart Footer */}
            {cartItems.length > 0 && (
              <div className="p-5 border-t border-slate-200 bg-slate-50 space-y-3">
                <div className="space-y-1.5 text-xs text-slate-600">
                  <div className="flex justify-between">
                    <span>قيمة الطلبات:</span>
                    <span className="font-bold tabular-nums text-slate-900">{subtotal} ج.م</span>
                  </div>
                  <div className="flex justify-between">
                    <span>خدمة التوصيل داخل فوه:</span>
                    <span className="font-bold tabular-nums text-slate-900">{deliveryFee} ج.م</span>
                  </div>
                  <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-1 border-t border-slate-200">
                    <span>الإجمالي المستحق:</span>
                    <span className="text-emerald-700 tabular-nums">{total} ج.م</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleStartCheckout}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 active:scale-[0.99]"
                >
                  <span>متابعة الدفع (انستا باي / فودافون كاش / كاش)</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
