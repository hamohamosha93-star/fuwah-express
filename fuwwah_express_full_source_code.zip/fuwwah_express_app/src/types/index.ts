export type Role = 'customer' | 'merchant' | 'courier' | 'dispatcher';

export type PaymentMethodType = 'instapay' | 'vodafone_cash' | 'orange_cash' | 'etisalat_cash' | 'we_pay' | 'smart_wallet' | 'cod';

export interface LocationPoint {
  lat: number;
  lng: number;
  name: string;
  district?: string;
  details?: string;
}

export interface ProductItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image?: string;
  category: string;
  isPopular?: boolean;
}

export interface Store {
  id: string;
  name: string;
  category: 'restaurant' | 'sweets' | 'grocery' | 'kilim_craft' | 'pharmacy';
  categoryAr: string;
  description: string;
  image: string;
  rating: number;
  deliveryTimeMins: string;
  minOrder: number;
  deliveryFee: number;
  address: string;
  location: LocationPoint;
  phone: string;
  products: ProductItem[];
}

export interface CartItem {
  product: ProductItem;
  quantity: number;
  storeId: string;
  storeName: string;
}

export type OrderStatus = 
  | 'pending_payment'
  | 'confirmed'
  | 'preparing'
  | 'courier_assigned'
  | 'on_the_way'
  | 'arrived'
  | 'delivered'
  | 'cancelled';

export type OrderType = 'store_order' | 'parcel_shipment';

export interface Courier {
  id: string;
  name: string;
  phone: string;
  whatsapp: string;
  rating: number;
  vehicle: string;
  plateNumber: string;
  currentLocation: [number, number];
  photo?: string;
}

export interface Order {
  id: string;
  trackingNumber: string;
  type: OrderType;
  customerName: string;
  customerPhone: string;
  recipientName?: string;
  recipientPhone?: string;
  pickupLocation: LocationPoint;
  dropoffLocation: LocationPoint;
  status: OrderStatus;
  createdAt: string;
  storeName?: string;
  storeId?: string;
  items?: { product: ProductItem; quantity: number }[];
  parcelDetails?: {
    category: string;
    description: string;
    weight: string;
    isFragile: boolean;
    packageValueEgp?: number;
  };
  subtotal: number;
  deliveryFee: number;
  total: number;
  paymentMethod: PaymentMethodType;
  paymentStatus: 'pending' | 'verified' | 'paid_cod';
  paymentReference?: string;
  courier?: Courier;
  deliveryCode: string;
  notes?: string;
  currentCourierLocation?: [number, number];
  etaMinutes?: number;
}
