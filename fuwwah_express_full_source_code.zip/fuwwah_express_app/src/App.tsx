import React, { useState } from 'react';
import { Role, Order, Store, CartItem, LocationPoint, PaymentMethodType, OrderStatus } from './types';
import { INITIAL_ORDERS, INITIAL_COURIERS } from './data/fuwwahData';
import { Navbar } from './components/Navbar';
import { StoreCatalog } from './components/StoreCatalog';
import { ParcelShippingForm } from './components/ParcelShippingForm';
import { OrderTrackingView } from './components/OrderTrackingView';
import { MerchantDashboard } from './components/MerchantDashboard';
import { CourierDashboard } from './components/CourierDashboard';
import { PaymentModal } from './components/PaymentModal';
import { ApkDownloadModal } from './components/ApkDownloadModal';
import {
  ShoppingBag,
  Package,
  Navigation,
  Store as StoreIcon,
  Bike,
  CheckCircle2,
  Clock,
  Sparkles,
  MapPin,
  HelpCircle,
  ExternalLink,
  Smartphone,
  Download,
} from 'lucide-react';

export default function App() {
  const [currentRole, setCurrentRole] = useState<Role>('customer');
  const [activeTab, setActiveTab] = useState<'stores' | 'parcel' | 'tracking' | 'merchant' | 'courier'>('stores');
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [selectedTrackOrderId, setSelectedTrackOrderId] = useState<string>(INITIAL_ORDERS[0].id);

  // Payment Modal State
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [pendingPaymentOrder, setPendingPaymentOrder] = useState<Partial<Order> | null>(null);

  // APK & Android Install Modal State
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  // Current active tracked order
  const activeOrder = orders.find((o) => o.id === selectedTrackOrderId) || orders[0];

  // Initiate Checkout for Store Order
  const handleStoreCheckout = (
    cart: CartItem[],
    store: Store,
    dropoff: LocationPoint,
    notes: string
  ) => {
    const subtotal = cart.reduce((acc, i) => acc + i.product.price * i.quantity, 0);
    const deliveryFee = store.deliveryFee;
    const total = subtotal + deliveryFee;

    const newOrderData: Partial<Order> = {
      type: 'store_order',
      storeName: store.name,
      storeId: store.id,
      customerName: 'الأستاذ أحمد فوه',
      customerPhone: '01012345678',
      pickupLocation: store.location,
      dropoffLocation: dropoff,
      items: cart.map((c) => ({ product: c.product, quantity: c.quantity })),
      subtotal,
      deliveryFee,
      total,
      notes,
    };

    setPendingPaymentOrder(newOrderData);
    setIsPaymentOpen(true);
  };

  // Initiate Checkout for Parcel Order
  const handleParcelOrderSubmit = (parcelOrderData: Partial<Order>) => {
    setPendingPaymentOrder(parcelOrderData);
    setIsPaymentOpen(true);
  };

  // On Payment Confirmation (InstaPay or Mobile Wallets or COD)
  const handlePaymentComplete = (method: PaymentMethodType, reference: string) => {
    if (!pendingPaymentOrder) return;

    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const trackingNumber = `FUW-${randomSuffix}`;
    const otpCode = String(Math.floor(1000 + Math.random() * 9000));

    const completedOrder: Order = {
      id: `ord_${Date.now()}`,
      trackingNumber,
      type: pendingPaymentOrder.type || 'store_order',
      customerName: pendingPaymentOrder.customerName || 'عميل فوه',
      customerPhone: pendingPaymentOrder.customerPhone || '01012345678',
      recipientName: pendingPaymentOrder.recipientName,
      recipientPhone: pendingPaymentOrder.recipientPhone,
      pickupLocation: pendingPaymentOrder.pickupLocation!,
      dropoffLocation: pendingPaymentOrder.dropoffLocation!,
      status: 'confirmed',
      createdAt: 'الآن',
      storeName: pendingPaymentOrder.storeName,
      storeId: pendingPaymentOrder.storeId,
      items: pendingPaymentOrder.items,
      parcelDetails: pendingPaymentOrder.parcelDetails,
      subtotal: pendingPaymentOrder.subtotal || 0,
      deliveryFee: pendingPaymentOrder.deliveryFee || 15,
      total: pendingPaymentOrder.total || 15,
      paymentMethod: method,
      paymentStatus: method === 'cod' ? 'paid_cod' : 'verified',
      paymentReference: reference,
      courier: INITIAL_COURIERS[Math.floor(Math.random() * INITIAL_COURIERS.length)],
      deliveryCode: otpCode,
      notes: pendingPaymentOrder.notes,
      currentCourierLocation: [
        pendingPaymentOrder.pickupLocation!.lat + 0.001,
        pendingPaymentOrder.pickupLocation!.lng - 0.001,
      ],
      etaMinutes: 15,
    };

    setOrders((prev) => [completedOrder, ...prev]);
    setSelectedTrackOrderId(completedOrder.id);
    setIsPaymentOpen(false);
    setPendingPaymentOrder(null);
    setActiveTab('tracking');
  };

  // Update order status from tracking or merchant/courier actions
  const handleUpdateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: newStatus } : o))
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-['Cairo',sans-serif]">
      {/* Primary Top Bar */}
      <Navbar
        currentRole={currentRole}
        onSelectRole={(r) => {
          setCurrentRole(r);
          if (r === 'merchant') setActiveTab('merchant');
          if (r === 'courier') setActiveTab('courier');
        }}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        activeOrdersCount={orders.filter((o) => o.status !== 'delivered').length}
      />

      {/* Role Switcher Toolbar & Orders Quick Strip */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
            <span className="text-[11px] font-bold text-slate-500 px-2">الواجهة الحالية:</span>
            <button
              type="button"
              onClick={() => {
                setCurrentRole('customer');
                setActiveTab('stores');
              }}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                currentRole === 'customer'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              العميل (طلب وشحن)
            </button>
            <button
              type="button"
              onClick={() => {
                setCurrentRole('merchant');
                setActiveTab('merchant');
              }}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                currentRole === 'merchant'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              التاجر (إدارة المتجر)
            </button>
            <button
              type="button"
              onClick={() => {
                setCurrentRole('courier');
                setActiveTab('courier');
              }}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                currentRole === 'courier'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              كابتن التوصيل (المندوب)
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* APK Download & Install Trigger Button */}
            <button
              type="button"
              onClick={() => setIsApkModalOpen(true)}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-xl font-bold text-xs shadow-sm transition-all active:scale-95"
            >
              <Smartphone className="w-4 h-4 text-emerald-200" />
              <span>تحميل وتثبيت التطبيق (APK)</span>
            </button>

            {/* Quick Active Orders Carousel / Indicator */}
            {orders.length > 0 && (
              <div className="hidden sm:flex items-center gap-2 pr-2 border-r border-slate-200">
                <span className="text-[11px] text-slate-500 font-semibold">شحنات فوه:</span>
                <div className="flex items-center gap-1.5 overflow-x-auto">
                  {orders.slice(0, 3).map((ord) => (
                    <button
                      key={ord.id}
                      onClick={() => {
                        setSelectedTrackOrderId(ord.id);
                        setActiveTab('tracking');
                      }}
                      className={`px-2.5 py-1 rounded-lg font-mono text-[11px] font-bold transition-colors ${
                        activeOrder?.id === ord.id && activeTab === 'tracking'
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                      }`}
                    >
                      {ord.trackingNumber}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* TAB 1: STORES */}
        {activeTab === 'stores' && (
          <StoreCatalog
            onCheckout={handleStoreCheckout}
            onOpenParcelForm={() => setActiveTab('parcel')}
            onOpenApkModal={() => setIsApkModalOpen(true)}
          />
        )}

        {/* TAB 2: PARCEL SHIPPING */}
        {activeTab === 'parcel' && (
          <ParcelShippingForm
            onSubmitParcelOrder={handleParcelOrderSubmit}
            onCancel={() => setActiveTab('stores')}
          />
        )}

        {/* TAB 3: ORDER TRACKING */}
        {activeTab === 'tracking' && (
          <OrderTrackingView
            order={activeOrder}
            onUpdateStatus={(newSt) => handleUpdateOrderStatus(activeOrder.id, newSt)}
            onBackToMain={() => setActiveTab('stores')}
          />
        )}

        {/* TAB 4: MERCHANT */}
        {activeTab === 'merchant' && (
          <MerchantDashboard
            orders={orders}
            onUpdateOrderStatus={(ordId, st) => handleUpdateOrderStatus(ordId, st)}
            onSelectTrackOrder={(ord) => {
              setSelectedTrackOrderId(ord.id);
              setActiveTab('tracking');
            }}
          />
        )}

        {/* TAB 5: COURIER */}
        {activeTab === 'courier' && (
          <CourierDashboard
            orders={orders}
            onUpdateOrderStatus={(ordId, st) => handleUpdateOrderStatus(ordId, st)}
            onSelectTrackOrder={(ord) => {
              setSelectedTrackOrderId(ord.id);
              setActiveTab('tracking');
            }}
          />
        )}
      </main>

      {/* Payment Gateway Modal */}
      {pendingPaymentOrder && (
        <PaymentModal
          isOpen={isPaymentOpen}
          onClose={() => {
            setIsPaymentOpen(false);
            setPendingPaymentOrder(null);
          }}
          amount={pendingPaymentOrder.total || 0}
          orderTitle={
            pendingPaymentOrder.type === 'parcel_shipment'
              ? `شحن طرد (${pendingPaymentOrder.parcelDetails?.category})`
              : `طلب من ${pendingPaymentOrder.storeName || 'متاجر فوه'}`
          }
          orderNumber={`FUW-${Math.floor(10000 + Math.random() * 90000)}`}
          onPaymentComplete={handlePaymentComplete}
        />
      )}

      {/* APK & Android Installation Modal */}
      <ApkDownloadModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Mobile Fixed Bottom Tab Bar (Responsive thumb ergonomics) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200">
        <div className="grid grid-cols-4 items-center h-16 max-w-md mx-auto">
          <button
            type="button"
            onClick={() => {
              setCurrentRole('customer');
              setActiveTab('stores');
            }}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'stores' ? 'text-emerald-700 font-bold' : 'text-slate-500'
            }`}
          >
            <StoreIcon className="w-5 h-5" />
            <span className="text-[10px] mt-1">المتاجر</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setCurrentRole('customer');
              setActiveTab('parcel');
            }}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'parcel' ? 'text-emerald-700 font-bold' : 'text-slate-500'
            }`}
          >
            <Package className="w-5 h-5" />
            <span className="text-[10px] mt-1">شحن طرد</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('tracking')}
            className={`flex flex-col items-center justify-center py-1 transition-colors relative ${
              activeTab === 'tracking' ? 'text-emerald-700 font-bold' : 'text-slate-500'
            }`}
          >
            <Navigation className="w-5 h-5" />
            <span className="text-[10px] mt-1">التتبع</span>
            {orders.length > 0 && (
              <span className="absolute top-2 left-1/2 -translate-x-4 w-2 h-2 rounded-full bg-emerald-600"></span>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              const nextRole = currentRole === 'courier' ? 'merchant' : 'courier';
              setCurrentRole(nextRole);
              setActiveTab(nextRole);
            }}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'courier' || activeTab === 'merchant'
                ? 'text-emerald-700 font-bold'
                : 'text-slate-500'
            }`}
          >
            <Bike className="w-5 h-5" />
            <span className="text-[10px] mt-1">
              {currentRole === 'courier' ? 'الكابتن' : 'التاجر'}
            </span>
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-900">فوه إكسبريس (Fuwwah Express)</span>
            <span aria-hidden="true">·</span>
            <span>مركز ومدينة فوه - محافظة كفر الشيخ - جمهورية مصر العربية</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>خدمة التوصيل اللحظي</span>
            <span>دفع عبر انستا باي IPN</span>
            <span>محافظ فودافون وأورنج واتصالات كاش</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
