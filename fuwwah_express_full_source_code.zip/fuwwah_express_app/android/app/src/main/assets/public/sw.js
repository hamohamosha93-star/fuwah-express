/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "a64aeb8b7f6f7ac468c215412d1f351c"
  }, {
    "url": "pwa-512x512.png",
    "revision": "a64aeb8b7f6f7ac468c215412d1f351c"
  }, {
    "url": "pwa-192x192.png",
    "revision": "5480cdac9028d3d878d213fe848654e4"
  }, {
    "url": "index.html",
    "revision": "b6862172853073417d179f7f848a3fdd"
  }, {
    "url": "icon.svg",
    "revision": "bf9b2f73dc009ed1f08a995e73753bc5"
  }, {
    "url": "favicon.ico",
    "revision": "566f764eb422bd892e215b528ba6df26"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "a0de9bb7958895b49424e678182176c0"
  }, {
    "url": "assets/index-OdHFdfjD.css",
    "revision": null
  }, {
    "url": "assets/index-BtJPR61a.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "a0de9bb7958895b49424e678182176c0"
  }, {
    "url": "favicon.ico",
    "revision": "566f764eb422bd892e215b528ba6df26"
  }, {
    "url": "icon.svg",
    "revision": "bf9b2f73dc009ed1f08a995e73753bc5"
  }, {
    "url": "pwa-192x192.png",
    "revision": "5480cdac9028d3d878d213fe848654e4"
  }, {
    "url": "pwa-512x512.png",
    "revision": "a64aeb8b7f6f7ac468c215412d1f351c"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "a64aeb8b7f6f7ac468c215412d1f351c"
  }, {
    "url": "manifest.webmanifest",
    "revision": "f8e74222433e83fb78473b782b57b067"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
