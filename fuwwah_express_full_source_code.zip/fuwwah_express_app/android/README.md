# Fuwwah Express - Android Native Project (فوه إكسبريس)

This is the complete ready-to-build Android Studio project for **فوه إكسبريس (Fuwwah Express)**.
Application ID: `com.fuwwah.express.delivery`

## How to Build the Signed APK:

### Option 1: Using Android Studio (GUI - Recommended)
1. Open **Android Studio**.
2. Click **Open** and select this `android` folder.
3. Wait for Gradle Sync to complete.
4. Go to menu: **Build** -> **Generate Signed Bundle / APK...**
5. Select **APK** and click **Next**.
6. Create or select a Key store path (e.g. `fuwwah-key.jks`), enter password, alias `fuwwah-key`.
7. Choose **release** destination and select **V1 and V2 (Full APK Signature)**.
8. Click **Finish**. Your signed release APK is generated in `app/release/app-release.apk`!

### Option 2: Using Command Line (Terminal / CI)
1. Generate keystore:
   ```bash
   keytool -genkey -v -keystore app/fuwwah-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias fuwwah-key
   ```
2. Build Release APK:
   ```bash
   ./gradlew assembleRelease
   ```
3. Locate the output signed APK:
   `app/build/outputs/apk/release/app-release.apk`
